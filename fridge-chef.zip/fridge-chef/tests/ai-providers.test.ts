import { describe, it, expect, vi, afterEach } from 'vitest';
import { callAI, callGemini, providerStatus, PROVIDER_CHAIN } from '@/lib/server-ai';

describe('final provider flow (Manan spec 2026-10-31) — Gemini is the only AI', () => {
  it('AI chain is gemini only, offline last in status', () => {
    expect(PROVIDER_CHAIN).toEqual(['gemini']);
    expect(providerStatus().chain).toEqual(['gemini', 'offline']);
  });
  it('Dish Guide flow is local database -> gemini', () => {
    expect(providerStatus().guideFlow).toEqual(['local-database', 'gemini']);
  });
  it('no other AI providers remain in the status', () => {
    const keys = Object.keys(providerStatus().providers);
    expect(keys.sort()).toEqual(['gemini', 'offline']);
  });
  it('status reports configuration from env presence only, with correct key name', () => {
    const s = providerStatus();
    expect(s.providers.gemini.keyEnv).toBe('GEMINI_API_KEY');
    expect(s.providers.offline.configured).toBe(true);
    expect(JSON.stringify(s)).not.toMatch(/sk-|AIza|gsk_/);
  });
});

describe('callAI is Gemini-only', () => {
  const realFetch = global.fetch;
  afterEach(() => { global.fetch = realFetch; delete process.env.GEMINI_API_KEY; vi.restoreAllMocks(); });
  it('returns gemini output when Gemini answers', async () => {
    process.env.GEMINI_API_KEY = 'test-key-not-real';
    global.fetch = vi.fn(async () => ({ ok: true, json: async () => ({ candidates: [{ content: { parts: [{ text: 'from-gemini' }] } }] }) } as Response)) as unknown as typeof fetch;
    const out = await callAI('prompt');
    expect(out).toEqual({ text: 'from-gemini', provider: 'gemini' });
  });
  it('throws when Gemini is unconfigured so callers use the offline library', async () => {
    delete process.env.GEMINI_API_KEY;
    await expect(callAI('prompt')).rejects.toThrow('GEMINI_API_KEY not set');
    await expect(callGemini('prompt')).rejects.toThrow('GEMINI_API_KEY not set');
  });
});

describe('Gemini model fallbacks (verified live 2026-10-31)', () => {
  it('never leads with a retired model and includes the verified-working preview model', async () => {
    const { GEMINI_MODEL_FALLBACKS } = await import('@/lib/server-ai');
    expect(GEMINI_MODEL_FALLBACKS).not.toContain('gemini-2.0-flash');
    expect(GEMINI_MODEL_FALLBACKS).not.toContain('gemini-2.5-flash');
    expect(GEMINI_MODEL_FALLBACKS[0]).toBe('gemini-3.8-flash');
    expect(GEMINI_MODEL_FALLBACKS).toContain('gemini-3-flash-preview');
  });
});
