import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { callAI, callMuse, providerStatus, PROVIDER_CHAIN } from '@/lib/server-ai';

describe('provider chain — free providers first, paid Muse last, offline final fallback', () => {
  it('chain order is gemini, openrouter, cerebras, groq, muse with offline last in status', () => {
    expect(PROVIDER_CHAIN).toEqual(['gemini', 'openrouter', 'cerebras', 'groq', 'muse']);
    expect(providerStatus().chain).toEqual(['gemini', 'openrouter', 'cerebras', 'groq', 'muse', 'offline']);
  });
  it('status reports configuration from env presence only, with correct key names and models', () => {
    const s = providerStatus();
    expect(s.providers.muse.keyEnv).toBe('MODEL_API_KEY');
    expect(s.providers.muse.model).toBe(process.env.MUSE_MODEL || 'muse-wonder-1.0');
    expect(s.providers.gemini.keyEnv).toBe('GEMINI_API_KEY');
    expect(s.providers.offline.configured).toBe(true);
    // status must never contain anything that looks like a key value
    expect(JSON.stringify(s)).not.toMatch(/sk-|AIza|gsk_/);
  });
});

describe('Muse provider (Meta Model API)', () => {
  const realFetch = global.fetch;
  beforeEach(() => { process.env.MODEL_API_KEY = 'test-key-not-real'; });
  afterEach(() => { global.fetch = realFetch; delete process.env.MODEL_API_KEY; delete process.env.META_MODEL_API_KEY; vi.restoreAllMocks(); });
  it('calls the OpenAI-compatible chat completions endpoint with bearer auth and muse-wonder-1.0', async () => {
    let seenUrl = ''; let seenInit: RequestInit | undefined;
    global.fetch = vi.fn(async (url: string | URL, init?: RequestInit) => { seenUrl = String(url); seenInit = init; return { ok: true, json: async () => ({ choices: [{ message: { content: '{"recipes":[]}' } }] }) } as Response; }) as typeof fetch;
    const text = await callMuse('give me a recipe as JSON');
    expect(text).toContain('recipes');
    expect(seenUrl).toBe('https://api.meta.ai/v1/chat/completions');
    const headers = seenInit?.headers as Record<string, string>;
    expect(headers.Authorization).toBe('Bearer test-key-not-real');
    const body = JSON.parse(String(seenInit?.body));
    expect(body.model).toBe('muse-wonder-1.0');
    expect(body.messages[0].content).toContain('recipe');
    // JSON mode is NOT forced — support on Meta Model API is undocumented; prompt + parser handle it
    expect(body.response_format).toBeUndefined();
  });
  it('fails cleanly without a key so the chain can fall through', async () => {
    delete process.env.MODEL_API_KEY;
    await expect(callMuse('x')).rejects.toThrow('MODEL_API_KEY not set');
  });
  it('callAI falls through Gemini -> Muse when Gemini is unconfigured', async () => {
    delete process.env.GEMINI_API_KEY;
    global.fetch = vi.fn(async () => ({ ok: true, json: async () => ({ choices: [{ message: { content: 'from-muse' } }] }) } as Response)) as unknown as typeof fetch;
    const out = await callAI('prompt');
    expect(out).toEqual({ text: 'from-muse', provider: 'muse' });
  });
  it('callAI reaches the FREE OpenRouter before paid Muse', async () => {
    delete process.env.GEMINI_API_KEY; process.env.OPENROUTER_API_KEY = 'or-test-key';
    const urls: string[] = [];
    global.fetch = vi.fn(async (url: string | URL) => { urls.push(String(url)); return { ok: true, json: async () => ({ choices: [{ message: { content: 'from-openrouter' } }] }) } as Response; }) as unknown as typeof fetch;
    const out = await callAI('prompt');
    expect(out).toEqual({ text: 'from-openrouter', provider: 'openrouter' });
    expect(urls[0]).toBe('https://openrouter.ai/api/v1/chat/completions');
    delete process.env.OPENROUTER_API_KEY;
  });
});

describe('Gemini model fallbacks (verified live 2026-10-31)', () => {
  it('never leads with a retired model and includes the verified-working preview model', async () => {
    const { GEMINI_MODEL_FALLBACKS } = await import('@/lib/server-ai');
    expect(GEMINI_MODEL_FALLBACKS).not.toContain('gemini-2.0-flash');
    expect(GEMINI_MODEL_FALLBACKS).not.toContain('gemini-2.5-flash');
    expect(GEMINI_MODEL_FALLBACKS[0]).toBe('gemini-3.8-flash');
    expect(GEMINI_MODEL_FALLBACKS).toContain('gemini-3-flash-preview');
  });
});

import { callOpenRouter, callCerebras } from '@/lib/server-ai';
describe('free providers — OpenRouter and Cerebras', () => {
  const realFetch = global.fetch;
  afterEach(() => { global.fetch = realFetch; delete process.env.OPENROUTER_API_KEY; delete process.env.CEREBRAS_API_KEY; vi.restoreAllMocks(); });
  it('OpenRouter calls its chat completions endpoint with the pinned model when OPENROUTER_MODEL is set', async () => {
    process.env.OPENROUTER_API_KEY = 'or-key'; process.env.OPENROUTER_MODEL = 'meta-llama/llama-3.3-70b-instruct:free';
    let url = ''; let body: Record<string, unknown> = {}; let auth = '';
    global.fetch = vi.fn(async (u: string | URL, init?: RequestInit) => { url = String(u); body = JSON.parse(String(init?.body)); auth = (init?.headers as Record<string, string>).Authorization; return { ok: true, json: async () => ({ choices: [{ message: { content: 'ok' } }] }) } as Response; }) as unknown as typeof fetch;
    await callOpenRouter('recipe please');
    expect(url).toBe('https://openrouter.ai/api/v1/chat/completions');
    expect(body.model).toBe('meta-llama/llama-3.3-70b-instruct:free');
    expect(auth).toBe('Bearer or-key');
    delete process.env.OPENROUTER_MODEL;
  });
  it('OpenRouter walks free-model fallbacks and ends at openrouter/free', async () => {
    process.env.OPENROUTER_API_KEY = 'or-key'; delete process.env.OPENROUTER_MODEL;
    const models: string[] = [];
    global.fetch = vi.fn(async (_u: string | URL, init?: RequestInit) => { const m = JSON.parse(String(init?.body)).model as string; models.push(m); if (m !== 'openrouter/free') return { ok: false, json: async () => ({}) } as Response; return { ok: true, json: async () => ({ choices: [{ message: { content: 'router-ok' } }] }) } as Response; }) as unknown as typeof fetch;
    const out = await callOpenRouter('recipe please');
    expect(out).toBe('router-ok');
    expect(models[models.length - 1]).toBe('openrouter/free');
    expect(models.length).toBeGreaterThan(1);
  });
  it('Cerebras calls its endpoint with llama-3.3-70b by default', async () => {
    process.env.CEREBRAS_API_KEY = 'cb-key';
    let url = ''; let body: Record<string, unknown> = {};
    global.fetch = vi.fn(async (u: string | URL, init?: RequestInit) => { url = String(u); body = JSON.parse(String(init?.body)); return { ok: true, json: async () => ({ choices: [{ message: { content: 'ok' } }] }) } as Response; }) as unknown as typeof fetch;
    await callCerebras('recipe please');
    expect(url).toBe('https://api.cerebras.ai/v1/chat/completions');
    expect(body.model).toBe('llama-3.3-70b');
  });
  it('both fail cleanly without keys so the chain falls through', async () => {
    await expect(callOpenRouter('x')).rejects.toThrow('OPENROUTER_API_KEY not set');
    await expect(callCerebras('x')).rejects.toThrow('CEREBRAS_API_KEY not set');
  });
  it('status advertises both free providers with their key env names', () => {
    const s = providerStatus();
    expect(s.providers.openrouter.keyEnv).toBe('OPENROUTER_API_KEY');
    expect(s.providers.cerebras.keyEnv).toBe('CEREBRAS_API_KEY');
    expect(s.providers.openrouter.notes).toContain('FREE');
    expect(s.providers.cerebras.notes).toContain('FREE');
  });
});
