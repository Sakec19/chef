import { describe, it, expect } from 'vitest';
import { ALL_CUISINES, CUISINE_GROUPS, isSpecificCuisine, sanitizeCuisines, recipeMatchesCuisines } from '@/lib/cuisines';
import { offlineGenerate, OFFLINE_RECIPES, recipesForCuisines } from '@/lib/offline-recipes';
import { findDish, scaleRecipeToServings, listGuideDishes } from '@/lib/dish-guide';
import { planMonth } from '@/lib/planning';

describe('specific cuisine taxonomy — no generalizations', () => {
  it('has no generic umbrella labels at all', () => {
    const lower = ALL_CUISINES.map(c => c.toLowerCase());
    for (const banned of ['indian', 'asian', 'chinese', 'italian', 'mexican', 'thai', 'mediterranean', 'fusion']) expect(lower).not.toContain(banned);
    expect(isSpecificCuisine('Indian')).toBe(false);
    expect(isSpecificCuisine('Punjabi')).toBe(true);
  });
  it('Indian cuisines are separate: Punjabi, Gujarati, Indian Fast Food, and more', () => {
    for (const c of ['Punjabi', 'Gujarati', 'Indian Fast Food', 'Indian Street Food (Chaat)', 'Indo-Chinese', 'Bengali', 'Maharashtrian', 'Rajasthani', 'Hyderabadi', 'Tamil', 'Kerala', 'Goan', 'Kashmiri', 'Mughlai', 'Chettinad']) expect(ALL_CUISINES).toContain(c);
    expect(ALL_CUISINES.length).toBeGreaterThanOrEqual(80);
    expect(CUISINE_GROUPS.length).toBeGreaterThanOrEqual(7);
  });
  it('sanitize keeps only known specific cuisines, canonical spelling, deduped', () => {
    expect(sanitizeCuisines(['punjabi', 'INDIAN', 'Gujarati', 'punjabi', 'Not A Cuisine', 'indian fast food'])).toEqual(['Punjabi', 'Gujarati', 'Indian Fast Food']);
    expect(sanitizeCuisines('Punjabi')).toEqual([]);
    expect(sanitizeCuisines(undefined)).toEqual([]);
  });
  it('every offline recipe uses a specific cuisine from the taxonomy', () => {
    for (const r of OFFLINE_RECIPES) { expect(ALL_CUISINES, r.title).toContain(r.cuisine); expect(isSpecificCuisine(r.cuisine)).toBe(true); }
  });
});

describe('cuisine-filtered generation & planning', () => {
  it('offlineGenerate honours cuisine even with no ingredient overlap', () => {
    const out = offlineGenerate(['zzzz-nothing'], 3, ['Gujarati']);
    expect(out.length).toBeGreaterThan(0); expect(out.every(r => r.cuisine === 'Gujarati')).toBe(true);
  });
  it('offlineGenerate with Punjabi + chickpeas returns the Punjabi chole first', () => {
    expect(offlineGenerate(['chickpeas'], 3, ['Punjabi'])[0].id).toBe('off-9');
  });
  it('recipesForCuisines falls back to full pool for unknown cuisine', () => {
    expect(recipesForCuisines(['Punjabi']).every(r => r.cuisine === 'Punjabi')).toBe(true);
    expect(recipesForCuisines(['Atlantean'])).toEqual(OFFLINE_RECIPES);
  });
  it('planMonth only uses selected cuisines', () => {
    const p = planMonth(2026, 0, { budget: 100000, restaurantNights: 0, allowRepeats: true, cuisines: ['Punjabi', 'Gujarati'] });
    const used = p.days.filter(d => d.recipe).map(d => d.recipe!.cuisine);
    expect(used.length).toBe(31); expect(used.every(c => c === 'Punjabi' || c === 'Gujarati')).toBe(true);
  });
  it('recipeMatchesCuisines matches case-insensitively', () => {
    expect(recipeMatchesCuisines('Punjabi', ['punjabi'])).toBe(true);
    expect(recipeMatchesCuisines('Punjabi', ['Gujarati'])).toBe(false);
    expect(recipeMatchesCuisines('Punjabi', [])).toBe(true);
  });
});

describe('dish guide — name a dish, get step-by-step', () => {
  it('finds dishes by exact name, alias and fuzzy tokens', () => {
    expect(findDish('Butter Chicken')?.cuisine).toBe('Mughlai');
    expect(findDish('murgh makhani')?.title).toBe('Butter Chicken');
    expect(findDish('dhokla')?.title).toBe('Gujarati Khaman Dhokla');
    expect(findDish('dhokla')?.cuisine).toBe('Gujarati');
    expect(findDish('hyderabadi chicken biryani')?.title).toBe('Hyderabadi Chicken Biryani');
    expect(findDish('pav bhaji')?.cuisine).toBe('Indian Fast Food');
    expect(findDish('samosa')?.cuisine).toBe('Indian Street Food (Chaat)');
  });
  it('every guide has ordered steps, ingredients and a specific cuisine', () => {
    for (const title of listGuideDishes()) {
      const g = findDish(title)!;
      expect(g.steps.length, title).toBeGreaterThanOrEqual(3);
      expect(g.ingredients.length, title).toBeGreaterThanOrEqual(2);
      expect(isSpecificCuisine(g.cuisine), title).toBe(true);
    }
  });
  it('returns null honestly for unknown dishes (no fabricated guide)', () => {
    expect(findDish('quantum soup of nowhere')).toBeNull();
    expect(findDish('')).toBeNull();
  });
  it('scaling a guide to servings scales quantities and cost', () => {
    const g = findDish('Rajma')!; const scaled = scaleRecipeToServings(g, g.servings * 2);
    expect(scaled.servings).toBe(g.servings * 2);
    expect(scaled.ingredients[0].quantity).toBe(g.ingredients[0].quantity * 2);
    expect(scaled.estimatedCost).toBeCloseTo(g.estimatedCost * 2, 1);
  });
});
