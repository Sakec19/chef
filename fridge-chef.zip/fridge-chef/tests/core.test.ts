import { describe, it, expect } from 'vitest';
import { convert, aggregate } from '@/lib/units';
import { violatesDiet, validateRecipes, parseIngredients } from '@/lib/dietary';
import { calculateNutrition, scaleNutrition } from '@/lib/nutrition';
import { buildShoppingList, planMonth, deductPantry, totalCost } from '@/lib/planning';
import { offlineGenerate, OFFLINE_RECIPES } from '@/lib/offline-recipes';
import type { PantryItem, Recipe } from '@/lib/types';

describe('unit conversions', () => {
  it('converts kg->g and cup->ml', () => { expect(convert(1, 'kg', 'g')).toBe(1000); expect(convert(1, 'cup', 'ml')).toBe(240); });
  it('refuses unsafe count->weight conversion', () => { expect(convert(2, 'piece', 'g')).toBeNull(); });
  it('aggregates compatible, keeps incompatible separate', () => {
    const out = aggregate([{ name: 'Rice', quantity: 500, unit: 'g' }, { name: 'rice', quantity: 1, unit: 'kg' }, { name: 'rice', quantity: 2, unit: 'piece' }]);
    expect(out).toHaveLength(2); expect(out.find(o => o.unit === 'g')?.quantity).toBe(1500);
  });
});
describe('dietary filtering (hard rules)', () => {
  const chicken = OFFLINE_RECIPES.find(r => r.id === 'off-8')!;
  const vegan = OFFLINE_RECIPES.find(r => r.id === 'off-2')!;
  it('flags chicken for vegetarian/vegan', () => { expect(violatesDiet(chicken, 'vegetarian')).toContain('chicken'); expect(violatesDiet(chicken, 'vegan')).toContain('chicken'); });
  it('passes vegan stew for vegan, flags egg recipe for vegetarian-no-egg', () => { expect(violatesDiet(vegan, 'vegan')).toEqual([]); const egg = OFFLINE_RECIPES.find(r => r.id === 'off-3')!; expect(violatesDiet(egg, 'vegetarian-no-egg').length).toBeGreaterThan(0); });
  it('validateRecipes drops violators and allergens', () => { expect(validateRecipes([chicken, vegan], 'vegan')).toEqual([vegan]); expect(validateRecipes([vegan], 'omnivore', ['lentils'])).toEqual([]); });
  it('parses pasted lists', () => { expect(parseIngredients('rice, eggs\nspinach; tomato')).toEqual(['rice', 'eggs', 'spinach', 'tomato']); });
});
describe('nutrition', () => {
  it('calculates from ingredient DB and scales per serving', () => { const n = calculateNutrition([{ name: 'oats', quantity: 100, unit: 'g' }], 1); expect(n.calories).toBe(389); expect(scaleNutrition(n, 1, 2).calories).toBe(778); });
  it('unknown foods contribute 0, not invented values', () => { expect(calculateNutrition([{ name: 'moon dust', quantity: 100, unit: 'g' }], 1).calories).toBe(0); });
});
describe('shopping & pantry', () => {
  const pantry: PantryItem[] = [{ id: '1', name: 'rice', quantity: 500, unit: 'g', category: 'Pantry staples', location: 'shelf', createdAt: 0 }];
  it('subtracts pantry with conversion', () => { const recipe = OFFLINE_RECIPES.find(r => r.id === 'off-3')!; const list = buildShoppingList([recipe], pantry); expect(list.find(i => i.name === 'rice')).toBeUndefined(); });
  it('deduct never goes negative', () => { const out = deductPantry(pantry, { ...OFFLINE_RECIPES[0], ingredients: [{ name: 'rice', quantity: 10, unit: 'kg' }] }); expect(out[0].quantity).toBe(0); });
  it('totalCost sums qty*price', () => { expect(totalCost([{ id: 'x', name: 'a', quantity: 2, unit: 'g', category: 'Other', unitPrice: 1.5, priceCertain: false, checked: false }])).toBe(3); });
});
describe('budget honesty', () => {
  it('never claims fit when over budget', () => { const p = planMonth(2026, 0, { budget: 10, restaurantNights: 2, allowRepeats: true }); expect(p.fitsBudget).toBe(false); expect(p.overBudget).toBeGreaterThan(0); expect(p.totalCost).toBe(p.groceryCost + p.restaurantCost); });
  it('fits when budget is large', () => { expect(planMonth(2026, 0, { budget: 100000, restaurantNights: 0, allowRepeats: true }).fitsBudget).toBe(true); });
});
describe('offline fallback', () => {
  it('returns recipes matching ingredients, else defaults', () => { expect(offlineGenerate(['lentils'])[0].id).toBe('off-2'); expect(offlineGenerate(['zzzz']).length).toBe(3); });
  it('all offline recipes have steps, ingredients and nutrition', () => { for (const r of OFFLINE_RECIPES) { expect(r.steps.length).toBeGreaterThan(0); expect(r.ingredients.length).toBeGreaterThan(0); expect(typeof r.nutrition.calories).toBe('number'); } });
});
