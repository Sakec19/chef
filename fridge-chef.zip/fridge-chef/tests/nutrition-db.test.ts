import { describe, it, expect } from 'vitest';
import { FOOD_DB, lookupFood, calculateNutrition, nutritionCoverage, estimateLineCost, priceForUnit, gramsFor } from '@/lib/nutrition';
import { buildShoppingList } from '@/lib/planning';
import { OFFLINE_RECIPES } from '@/lib/offline-recipes';

describe('expanded nutrition database', () => {
  it('has at least 110 foods across all categories', () => {
    expect(Object.keys(FOOD_DB).length).toBeGreaterThanOrEqual(110);
    const cats = new Set(Object.values(FOOD_DB).map(f => f.category));
    for (const c of ['protein', 'dairy', 'grain', 'legume', 'vegetable', 'fruit', 'fat', 'pantry', 'herb']) expect(cats.has(c as never)).toBe(true);
  });
  it('every entry has sane values', () => {
    for (const [name, f] of Object.entries(FOOD_DB)) {
      expect(f.calories, name).toBeGreaterThanOrEqual(0); expect(f.calories, name).toBeLessThan(950);
      expect(f.protein, name).toBeGreaterThanOrEqual(0); expect(f.protein, name).toBeLessThanOrEqual(100);
    }
  });
  it('longest-match lookup wins: sweet potato, oat milk, chicken breast, feta cheese', () => {
    expect(lookupFood('roasted sweet potato')?.key).toBe('sweet potato');
    expect(lookupFood('oat milk latte')?.key).toBe('oat milk');
    expect(lookupFood('grilled chicken breast fillet')?.key).toBe('chicken breast');
    expect(lookupFood('crumbled feta cheese')?.key).toBe('feta cheese');
  });
  it('aliases resolve: courgette=zucchini values, aubergine=eggplant values', () => {
    expect(lookupFood('courgette')?.calories).toBe(lookupFood('zucchini')?.calories);
    expect(lookupFood('aubergine')?.calories).toBe(lookupFood('eggplant')?.calories);
  });
  it('piece weights: 1 egg ≈ 50g, 1 garlic clove ≈ 3g, tbsp oil = 15g', () => {
    expect(gramsFor({ name: 'egg', quantity: 1, unit: 'piece' })).toBe(50);
    expect(gramsFor({ name: 'garlic', quantity: 2, unit: 'clove' })).toBe(6);
    expect(gramsFor({ name: 'olive oil', quantity: 1, unit: 'tbsp' })).toBe(15);
    const n = calculateNutrition([{ name: 'egg', quantity: 1, unit: 'piece' }], 1);
    expect(n.calories).toBe(78); // 155 kcal/100g × 50g
  });
  it('new foods calculate: broccoli, quinoa, greek yogurt, avocado', () => {
    expect(calculateNutrition([{ name: 'broccoli', quantity: 100, unit: 'g' }], 1).calories).toBe(34);
    expect(calculateNutrition([{ name: 'quinoa', quantity: 100, unit: 'g' }], 1).protein).toBe(4.4);
    expect(calculateNutrition([{ name: 'greek yogurt', quantity: 100, unit: 'g' }], 1).protein).toBe(9);
    expect(calculateNutrition([{ name: 'avocado', quantity: 1, unit: 'piece' }], 1).calories).toBe(240);
  });
  it('coverage reports % of ingredients found in DB', () => {
    expect(nutritionCoverage([{ name: 'rice', quantity: 100, unit: 'g' }, { name: 'moon dust', quantity: 1, unit: 'g' }])).toBe(50);
    expect(nutritionCoverage(OFFLINE_RECIPES[0].ingredients)).toBe(100); // pasta, spinach, garlic, olive oil all known now
  });
});
describe('realistic prices (per-100g model)', () => {
  it('450g chicken costs single-digit dollars, not hundreds', () => {
    const cost = estimateLineCost('chicken', 450, 'g');
    expect(cost).toBeGreaterThan(2); expect(cost).toBeLessThan(8);
  });
  it('200g pasta is under $1, 1kg rice under $3', () => {
    expect(estimateLineCost('pasta', 200, 'g')).toBeLessThan(1);
    expect(estimateLineCost('rice', 1, 'kg')).toBeLessThan(3);
  });
  it('piece pricing: 3 eggs cost roughly $0.90', () => {
    expect(estimateLineCost('egg', 3, 'piece')).toBeCloseTo(0.9, 1);
  });
  it('shopping list total for a chicken-rice recipe is realistic', () => {
    const recipe = OFFLINE_RECIPES.find(r => r.id === 'off-8')!;
    const list = buildShoppingList([recipe], []);
    const total = list.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
    expect(total).toBeGreaterThan(3); expect(total).toBeLessThan(20);
    expect(priceForUnit('chicken', 'g')).toBeLessThan(0.05);
  });
});
