# Fridge Chef 🥬

AI-powered recipe generator, pantry manager, grocery assistant and meal planner. **No Claude/ChatGPT sign-in for users.** AI keys live only on the server. Works offline as a PWA.

## Features
- **Cook** — paste/type ingredients, diet (omnivore / vegetarian / vegetarian-no-egg / vegan as *hard* validation rules), allergen exclusions (with safety warning), **specific-cuisine multi-select (see below)**, meal/time/servings/skill filters → 3 recipes with quantities, steps, estimated nutrition, benefits, have-vs-buy marking, scaling, save/favourite, share, cooking mode, confirmed-only pantry deduction.
- **Pantry** — fridge/freezer/shelf, quantity/unit/category/purchase/expiry, expiring-soon alerts + use-it-up recipes, aggregation, adjustment history, never-negative quantities.
- **Month** — monthly dinner calendar, editable budget (default $100 example), restaurant nights priced separately, honest budget logic (never claims fit unless calculated total ≤ budget; shows amount over), swaps, consolidated shopping list.
- **My Days** — arbitrary dates, breakfast+lunch+dinner per day, daily calorie totals, regenerate/swap, combined shopping, persisted offline.
- **Shop** — auto-generated from Cook/Month/My Days, duplicates combined, pantry subtracted with safe unit conversions only, grouped by category, checkboxes persist, custom items, share as text, export JSON, prices flagged as estimates.
- **Settings** — theme, JSON backup/restore, iPhone Add to Home Screen guide, privacy/data disclosure, delete-all-data.
- **Nutrition** — calculated from a local ingredient database of **137 foods** (USDA-typical per-100g values in `lib/nutrition.ts`, 9 categories: protein, dairy, grains, legumes, vegetables, fruit, fats, pantry, herbs), *not* invented by the AI. Longest-match lookup (`sweet potato` ≠ `potato`, `oat milk` ≠ `milk`), per-food piece weights (egg 50g, garlic clove 3g), tbsp/tsp/oz/lb/can conversions, and a nutrition-coverage % shown on any recipe whose ingredients aren't all in the DB. Estimates only, not medical advice.
- **Offline/PWA** — manifest + service worker (app shell + pages cached, `/api/` never cached), IndexedDB (versioned, `fridge-chef` v1) for pantry/recipes/plans/shop, offline banner, offline recipe fallback.

## Specific cuisines — no generic labels
Cuisine selection (`lib/cuisines.ts`) uses **specific regional/style cuisines only**. There is deliberately **no "Indian", "Asian", "Chinese" or "Italian" option** — instead: **Punjabi, Gujarati, Bengali, Maharashtrian, Rajasthani, Kashmiri, Goan, Hyderabadi, Chettinad, Tamil, Kerala, Mughlai, Indian Fast Food, Indian Street Food (Chaat), Indo-Chinese, Mumbai/Delhi/Kolkata Street Food**, plus dozens more worldwide (83 cuisines total) (Sichuan is not Cantonese, Neapolitan is not Roman, Oaxacan is not Tex-Mex) in 7 searchable groups. The picker is on **Cook, Month and My Days**; the server validates selections against the taxonomy (a generic label sent to the API is discarded, never honoured), the AI prompt makes the selection a hard rule, and offline generation/month planning filter their recipe pool by it. Generic labels are also rejected by a test.

## Dish Guide — name a dish, cook it step by step
On the Cook page: type any dish name (e.g. *Butter Chicken, Dhokla, Masala Dosa*) → full recipe via `POST /api/guide` (Gemini → Groq → offline library), scaled to your servings and diet. Includes a **mise-en-place ingredient checklist** (with in-pantry/need-to-buy marking) and a **guided cooking mode**: one step at a time, progress bar, Previous/Next, finish state. The offline library (`lib/dish-guide.ts`) covers 22 dishes including Butter Chicken, Palak Paneer, Rajma, Gujarati Khaman Dhokla, Hyderabadi Chicken Biryani, Masala Dosa, Aloo Paratha and Punjabi Samosa — unknown dishes offline return an honest "not in the library" with the available list, never a fabricated recipe.

## AI provider flow (final spec, 2026-10-31)

**Gemini is the only AI provider.** Every other provider that was integrated during
development (OpenAI, OpenRouter, Cerebras, Groq, Muse / Meta Model API) has been
**removed from the app at the owner's request**.

**Step-by-step Dish Guide:** **local dish database → Gemini.**
The built-in library of 22 dishes is checked FIRST (instant, free, hand-verified recipes).
Only if the dish is not in the library — or is in the library but violates the selected
diet/allergen rules and needs adapting — does the server call Gemini. If Gemini is
unavailable and the dish is not in the library, the API returns an honest
"not in the local dish database" response with the available list — never a fabricated recipe.

**Cook recipe generation:** **Gemini → offline recipe pool.**

1. **Google Gemini** (`GEMINI_API_KEY`, `GEMINI_MODEL`, default `gemini-3.8-flash`) — free tier within Google limits, key from Google AI Studio. **Model IDs verified live 2026-10-31:** `gemini-2.0-flash` is retired (404) and `gemini-2.5-flash` refuses new accounts, so the app walks a fallback list (`gemini-3.8-flash` → `gemini-3-flash-preview` → `gemini-flash-latest`). A real Pav Bhaji guide (17 steps) was generated live on `gemini-3-flash-preview`.
2. **Built-in offline library** — local dish database + offline recipe pool, always available, no key.

Check what's connected: open **Settings → AI providers** in the app, or `GET /api/ai-status` — it reports only whether each key is configured plus the model name, never any key value. "Configured" does not prove validity/billing; the first real generation is the true test.

Server route `app/api/generate/route.ts`: JSON-schema prompt, robust JSON parsing, server-side dietary validation of AI output, 15s timeouts, 1 retry (Gemini), in-memory rate limit 30 req/hour/IP, 8 KB request cap, no stack traces or keys exposed. **Production note:** in-memory rate limiting resets per serverless instance — add Upstash Redis for strict multi-instance limits before heavy public traffic.

## Windows PowerShell — local setup
```powershell
cd fridge-chef
node --version   # need 18+
npm install
Copy-Item .env.example .env.local   # then edit .env.local and paste your own keys (never share/commit)
npm run dev      # http://localhost:3000
npm test         # 46 unit tests
npm run build; npm run start
```
The app runs fully **without any keys** — generation falls back to the offline library.

## GitHub upload
```powershell
git init; git add .; git commit -m "Fridge Chef v1"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/fridge-chef.git
git push -u origin main
```
`.env.local` is git-ignored. Never commit keys.

## Vercel deployment
1. Go to vercel.com → Add New Project → import the GitHub repo (framework auto-detects Next.js).
2. Project → Settings → Environment Variables, add the keys you have: `GEMINI_API_KEY`, `MODEL_API_KEY` (Muse), `GROQ_API_KEY`, and optionally `GEMINI_MODEL`, `MUSE_MODEL`, `GROQ_MODEL`. Any subset works — missing providers are skipped.
3. Deploy. Every later `git push` to `main` auto-deploys.
4. **Updating is safe for users:** pantry/recipes/plans live in each user's browser IndexedDB (keyed by your domain), not on Vercel — redeploying does not delete user data. Keep the same domain and don't rename the IndexedDB database (`fridge-chef`) or bump its version without a migration in `lib/db.ts`. Advise users to export a JSON backup (Settings) before major changes, and note iOS home-screen storage is separate from Safari storage.

## Data sent to AI providers
Only the ingredient list, diet, allergens and filters from a Generate tap go to the server, then to Gemini (or Groq on fallback). No identity, account, or pantry history is sent.

## Production-readiness checklist
- [x] Production build passes (`npm run build`)
- [x] Unit tests pass (46/46): dietary, units, nutrition DB (137 foods), realistic prices, shopping, budget, offline, cuisine taxonomy (no generic labels), cuisine-filtered generation/planning, dish-guide lookup/scaling, Muse provider (endpoint/auth/model verified against Meta Model API docs; live call not yet run — no key)
- [x] Security headers + CSP in `next.config.mjs`
- [x] Keys server-only, `.env.example` has names only
- [ ] Set real keys in Vercel and verify Gemini + Groq in production
- [ ] Replace in-memory rate limit with Upstash/Redis for scale
- [ ] Real-device test: iPhone Safari + home-screen install, Android Chrome
- [ ] Replace placeholder solid-color icons with branded artwork
- [ ] Food photography: add only licensed/own images (none bundled, to avoid copyright issues)

## Testing honesty
Automated tests + production build + local API smoke test were run in the build environment. Gemini/Groq live calls, Safari and real iPhone home-screen behaviour were **not** verified — no API keys or real devices were available there. Test those after setting keys / on your iPhone.

## Limitations
Nutrition/price data cover 137 foods as built-in estimate tables (extend `lib/nutrition.ts` — add one `F(...)` line + one price entry per food); prices are USD per-100g planning estimates converted per unit, never verified store prices; month planner uses the offline collection for costing; AI recipes cannot guarantee allergen safety.
