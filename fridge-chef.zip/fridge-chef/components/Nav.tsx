'use client';
import Link from 'next/link'; import { usePathname } from 'next/navigation'; import { useEffect, useState } from 'react';
const links = [
  { href: '/', label: 'Cook', icon: '🍳' }, { href: '/pantry', label: 'Pantry', icon: '🧺' },
  { href: '/month', label: 'Month', icon: '📅' }, { href: '/my-days', label: 'My Days', icon: '🗓️' },
  { href: '/shop', label: 'Shop', icon: '🛒' }, { href: '/settings', label: 'Settings', icon: '⚙️' },
];
export default function Nav() {
  const path = usePathname(); const [online, setOnline] = useState(true); const [dark, setDark] = useState(false);
  useEffect(() => { const s = () => setOnline(navigator.onLine); s(); window.addEventListener('online', s); window.addEventListener('offline', s);
    const saved = localStorage.getItem('fc-theme'); const isDark = saved === 'dark' || (!saved && matchMedia('(prefers-color-scheme: dark)').matches); setDark(isDark); document.documentElement.classList.toggle('dark', isDark);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => { window.removeEventListener('online', s); window.removeEventListener('offline', s); }; }, []);
  function toggleTheme() { const next = !dark; setDark(next); document.documentElement.classList.toggle('dark', next); localStorage.setItem('fc-theme', next ? 'dark' : 'light'); }
  return <>
    {!online && <div role="status" className="bg-warm text-white text-center text-sm py-2 px-3">You&apos;re offline — saved &amp; built-in recipes, pantry and lists still work. AI generation is unavailable.</div>}
    <header className="max-w-5xl mx-auto flex items-center justify-between px-4 pt-4">
      <Link href="/" className="font-serif text-2xl font-bold text-forest dark:text-sage">🥬 Fridge Chef</Link>
      <button onClick={toggleTheme} aria-label="Toggle theme" className="btn-secondary">{dark ? '☀️ Light' : '🌙 Dark'}</button>
    </header>
    <nav aria-label="Main" className="fixed bottom-0 inset-x-0 z-50 bg-white/95 dark:bg-[#16221B]/95 backdrop-blur border-t border-black/10 md:sticky md:top-0 md:border-b md:border-t-0">
      <div className="max-w-5xl mx-auto grid grid-cols-6">
        {links.map(l => <Link key={l.href} href={l.href} aria-current={path === l.href ? 'page' : undefined} className={`flex flex-col items-center py-2 text-[11px] sm:text-xs font-semibold min-h-[56px] justify-center ${path === l.href ? 'text-forest dark:text-sage' : 'text-black/60 dark:text-white/60'}`}><span aria-hidden className="text-xl">{l.icon}</span>{l.label}</Link>)}
      </div>
    </nav>
  </>;
}
