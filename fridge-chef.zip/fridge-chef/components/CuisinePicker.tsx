'use client';
import { useMemo, useState } from 'react';
import { CUISINE_GROUPS } from '@/lib/cuisines';

export default function CuisinePicker({ selected, onChange, label = 'Cuisines (specific regions & styles — pick any)' }: { selected: string[]; onChange: (next: string[]) => void; label?: string }) {
  const [query, setQuery] = useState(''); const [open, setOpen] = useState(false);
  const groups = useMemo(() => CUISINE_GROUPS.map(g => ({ group: g.group, cuisines: g.cuisines.filter(c => !query || c.toLowerCase().includes(query.toLowerCase())) })).filter(g => g.cuisines.length), [query]);
  function toggle(c: string) { onChange(selected.includes(c) ? selected.filter(x => x !== c) : [...selected, c]); }
  return <div>
    <div className="flex items-center justify-between gap-2">
      <span className="text-sm font-semibold">{label}</span>
      <button type="button" className="btn-secondary !min-h-[36px] !py-1 text-xs" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? 'Hide list' : `Choose cuisines${selected.length ? ` (${selected.length} selected)` : ''}`}</button>
    </div>
    {selected.length > 0 && <div className="flex flex-wrap gap-1 mt-2">{selected.map(c => <button type="button" key={c} onClick={() => toggle(c)} className="chip !bg-forest !text-white" aria-label={`Remove ${c}`}>{c} ✕</button>)}
      <button type="button" onClick={() => onChange([])} className="chip">Clear all</button></div>}
    <p className="text-xs opacity-70 mt-1">No generic labels — Punjabi, Gujarati, Indian Fast Food, Mughlai etc. are separate cuisines, because they cook differently.</p>
    {open && <div className="mt-2 border border-black/10 dark:border-white/15 rounded-xl p-3 max-h-80 overflow-auto bg-white dark:bg-[#16221B]">
      <input className="input mb-3" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search cuisines… e.g. punjabi, gujarati, chaat, sichuan" aria-label="Search cuisines" />
      {groups.length === 0 && <p className="text-sm opacity-70">No cuisine matches that search.</p>}
      {groups.map(g => <fieldset key={g.group} className="mb-3"><legend className="font-bold text-sm mb-1">{g.group}</legend>
        <div className="flex flex-wrap gap-1">{g.cuisines.map(c => <button type="button" key={c} onClick={() => toggle(c)} aria-pressed={selected.includes(c)} className={`chip ${selected.includes(c) ? '!bg-forest !text-white font-bold' : ''}`}>{c}</button>)}</div></fieldset>)}
    </div>}
  </div>;
}
