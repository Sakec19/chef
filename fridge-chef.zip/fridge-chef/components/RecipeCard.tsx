'use client';
import type { Recipe, PantryItem } from '@/lib/types'; import { useState } from 'react'; import { nutritionCoverage } from '@/lib/nutrition';
export default function RecipeCard({ recipe, pantry = [], onSave, onCooked, onShop }: { recipe: Recipe; pantry?: PantryItem[]; onSave?: () => void; onCooked?: () => void; onShop?: () => void }) {
  const [open, setOpen] = useState(false); const [cookMode, setCookMode] = useState(false); const [scale, setScale] = useState(recipe.servings);
  const have = (name: string) => pantry.some(p => p.name.toLowerCase() === name.toLowerCase() && p.quantity > 0);
  const factor = scale / recipe.servings;
  return <article className="card">
    <div className="flex gap-3"><div aria-hidden className="text-5xl bg-sageLight dark:bg-[#24382D] rounded-2xl w-20 h-20 grid place-items-center shrink-0">🍽️</div>
    <div><h3 className="font-serif text-xl font-bold">{recipe.title}</h3><p className="text-sm opacity-80">{recipe.description}</p>
    <p className="text-xs mt-1 font-semibold">⏱ {recipe.timeMinutes} min · {recipe.cuisine} · {recipe.difficulty} · via {recipe.source} · ~${recipe.estimatedCost.toFixed(2)}</p></div></div>
    <p className="mt-3 text-sm"><strong>Per serving (estimate):</strong> {Math.round(recipe.nutrition.calories * factor)} kcal · {recipe.nutrition.protein}g protein · {recipe.nutrition.carbs}g carbs · {recipe.nutrition.fat}g fat{recipe.nutrition.fiber ? ` · ${recipe.nutrition.fiber}g fiber` : ''}{nutritionCoverage(recipe.ingredients) < 100 ? ` · based on ${nutritionCoverage(recipe.ingredients)}% of ingredients in nutrition DB` : ''}</p>
    {recipe.benefits.length > 0 && <p className="text-sm mt-1">✨ {recipe.benefits.join(' · ')}</p>}
    <label className="text-sm font-semibold mt-3 block">Servings <input aria-label="Servings" type="number" min={1} max={12} value={scale} onChange={e => setScale(Number(e.target.value))} className="input !w-20 inline-block ml-2" /></label>
    <button className="btn-secondary mt-2" onClick={() => setOpen(!open)}>{open ? 'Hide' : 'Show'} ingredients &amp; steps</button>
    {open && <div className="mt-3"><h4 className="font-bold">Ingredients</h4><ul className="list-disc pl-5 text-sm space-y-1">{recipe.ingredients.map((i, idx) => <li key={idx}>{Math.round(i.quantity * factor * 100) / 100} {i.unit} {i.name} — {i.staple ? <em>optional pantry staple</em> : have(i.name) ? <span className="text-forest2 dark:text-sage font-semibold">in pantry ✓</span> : <span className="text-warm font-semibold">need to buy</span>}{i.optional ? ' (optional)' : ''}</li>)}</ul>
    <h4 className="font-bold mt-3">Steps</h4><ol className="list-decimal pl-5 text-sm space-y-1">{recipe.steps.map((s, i) => <li key={i} className={cookMode ? 'text-base py-1' : ''}>{s}</li>)}</ol></div>}
    <div className="flex flex-wrap gap-2 mt-3">
      {onSave && <button className="btn-secondary" onClick={onSave}>♥ Save</button>}
      {onShop && <button className="btn-secondary" onClick={onShop}>🛒 Add missing to Shop</button>}
      <button className="btn-secondary" onClick={() => setCookMode(!cookMode)}>{cookMode ? 'Exit cooking mode' : '👩‍🍳 Cooking mode'}</button>
      {onCooked && <button className="btn-secondary" onClick={() => { if (confirm('Confirm you cooked this? Pantry quantities will be deducted.')) onCooked(); }}>✓ Cooked — deduct pantry</button>}
      <button className="btn-secondary" onClick={() => navigator.share?.({ title: recipe.title, text: `${recipe.title}\n${recipe.steps.join('\n')}` }).catch(() => {})}>Share</button>
    </div>
  </article>;
}
