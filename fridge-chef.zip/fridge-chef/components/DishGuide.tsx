'use client';
import { useState } from 'react';
import type { Diet, PantryItem, Recipe } from '@/lib/types';
import { findDish, scaleRecipeToServings, listGuideDishes } from '@/lib/dish-guide';
import { parseIngredients } from '@/lib/dietary';

export default function DishGuide({ pantry = [], onSave, onShop }: { pantry?: PantryItem[]; onSave?: (r: Recipe) => void; onShop?: (r: Recipe) => void }) {
  const [dish, setDish] = useState(''); const [servings, setServings] = useState(2); const [diet, setDiet] = useState<Diet>('omnivore'); const [allergens, setAllergens] = useState('');
  const [recipe, setRecipe] = useState<Recipe | null>(null); const [msg, setMsg] = useState(''); const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0); const [walking, setWalking] = useState(false); const [checked, setChecked] = useState<Set<number>>(new Set());
  const suggestions = listGuideDishes();

  async function lookup(name?: string) {
    const q = (name ?? dish).trim(); if (!q) { setMsg('Type a dish name first — e.g. Butter Chicken, Dhokla, Pav Bhaji.'); return; }
    setDish(q); setLoading(true); setMsg(''); setRecipe(null); setWalking(false); setStep(0); setChecked(new Set());
    // Offline: answer straight from the built-in library, no network needed.
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      const found = findDish(q); setLoading(false);
      if (found) { setRecipe(scaleRecipeToServings(found, servings)); setMsg('Offline guide from the built-in dish library.'); }
      else setMsg(`"${q}" isn't in the offline dish library, and AI needs a connection. Offline dishes are listed below.`);
      return;
    }
    try {
      const res = await fetch('/api/guide', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dish: q, servings, diet, allergens: parseIngredients(allergens) }) });
      const data = await res.json();
      if (!res.ok) { setMsg(data.error || 'Could not load that dish.'); if (data.availableOffline) setMsg(m => m + ' Available offline: ' + (data.availableOffline as string[]).slice(0, 8).join(', ') + '…'); setLoading(false); return; }
      setRecipe(data.recipe); setMsg(`Guide via ${data.provider}. ${data.note || ''}`);
    } catch { const found = findDish(q); if (found) { setRecipe(scaleRecipeToServings(found, servings)); setMsg('Connection failed — showing the offline guide instead.'); } else setMsg('Connection failed and that dish is not in the offline library.'); }
    setLoading(false);
  }
  const have = (name: string) => pantry.some(p => p.name.toLowerCase() === name.toLowerCase() && p.quantity > 0);
  return <section className="card space-y-3" aria-label="Dish guide">
    <h2 className="font-serif text-2xl font-bold">🍛 Dish Guide — name a dish, cook it step by step</h2>
    <p className="text-sm opacity-80">Type any dish name and get the full recipe with guided, one-step-at-a-time cooking mode.</p>
    <div className="flex flex-wrap gap-2">
      <input className="input flex-1 min-w-[200px]" value={dish} onChange={e => setDish(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') lookup(); }} placeholder="e.g. Butter Chicken, Gujarati Dhokla, Masala Dosa, Pav Bhaji…" aria-label="Dish name" />
      <label className="text-sm font-semibold">Servings<input type="number" min={1} max={12} className="input !w-20 ml-1" value={servings} onChange={e => setServings(Number(e.target.value))} /></label>
      <button className="btn" onClick={() => lookup()} disabled={loading}>{loading ? 'Loading guide…' : 'Get step-by-step guide'}</button>
    </div>
    <div className="grid sm:grid-cols-2 gap-3">
      <label className="text-sm font-semibold">Diet<select className="input mt-1" value={diet} onChange={e => setDiet(e.target.value as Diet)}><option value="omnivore">Omnivore</option><option value="vegetarian">Vegetarian</option><option value="vegetarian-no-egg">Vegetarian (no eggs)</option><option value="vegan">Vegan</option></select></label>
      <label className="text-sm font-semibold">Allergen exclusions<input className="input mt-1" value={allergens} onChange={e => setAllergens(e.target.value)} placeholder="e.g. peanut" /></label>
    </div>
    <div><p className="text-xs font-semibold mb-1">Popular offline guides (work without internet):</p>
      <div className="flex flex-wrap gap-1">{suggestions.slice(0, 14).map(s => <button key={s} type="button" className="chip" onClick={() => lookup(s)}>{s}</button>)}</div></div>
    {msg && <p role="status" className="text-sm bg-sageLight dark:bg-[#24382D] rounded-xl p-3">{msg}</p>}
    {loading && <div className="skeleton h-32" aria-label="Loading" />}
    {recipe && <article className="border border-black/10 dark:border-white/15 rounded-2xl p-4 space-y-3">
      <div><h3 className="font-serif text-2xl font-bold">{recipe.title}</h3>
        <p className="text-sm opacity-80">{recipe.description}</p>
        <p className="text-xs mt-1 font-semibold">⏱ {recipe.timeMinutes} min · {recipe.cuisine} · {recipe.difficulty} · {recipe.servings} servings · via {recipe.source}</p>
        <p className="text-sm mt-1"><strong>Per serving (estimate):</strong> {recipe.nutrition.calories} kcal · {recipe.nutrition.protein}g protein · {recipe.nutrition.carbs}g carbs · {recipe.nutrition.fat}g fat</p></div>
      {!walking ? <>
        <div><h4 className="font-bold">Ingredients — tick off as you prep (mise en place)</h4>
          <ul className="space-y-1 text-sm">{recipe.ingredients.map((i, idx) => <li key={idx}><label className="flex gap-2 items-center"><input type="checkbox" className="w-5 h-5" checked={checked.has(idx)} onChange={() => setChecked(p => { const n = new Set(p); if (n.has(idx)) { n.delete(idx); } else { n.add(idx); } return n; })} /><span className={checked.has(idx) ? 'line-through opacity-60' : ''}>{i.quantity} {i.unit} {i.name}{i.staple ? ' (pantry staple)' : have(i.name) ? ' — in pantry ✓' : ' — need to buy'}{i.optional ? ' (optional)' : ''}</span></label></li>)}</ul></div>
        <div><h4 className="font-bold">All steps</h4><ol className="list-decimal pl-5 text-sm space-y-1">{recipe.steps.map((s, i) => <li key={i}>{s}</li>)}</ol></div>
        <div className="flex flex-wrap gap-2"><button className="btn" onClick={() => { setWalking(true); setStep(0); }}>▶ Start step-by-step cooking</button>
          {onSave && <button className="btn-secondary" onClick={() => onSave(recipe)}>♥ Save for offline</button>}
          {onShop && <button className="btn-secondary" onClick={() => onShop(recipe)}>🛒 Add missing to Shop</button>}</div>
      </> : <div className="space-y-3">
        <div className="flex items-center justify-between text-sm font-semibold"><span>Step {step + 1} of {recipe.steps.length}</span><span>{Math.round(((step + 1) / recipe.steps.length) * 100)}%</span></div>
        <div className="h-2 rounded-full bg-black/10 overflow-hidden"><div className="h-full bg-forest transition-all" style={{ width: `${((step + 1) / recipe.steps.length) * 100}%` }} /></div>
        <p className="text-lg leading-relaxed bg-sageLight dark:bg-[#24382D] rounded-2xl p-4">{recipe.steps[step]}</p>
        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary" disabled={step === 0} onClick={() => setStep(step - 1)}>← Previous</button>
          {step < recipe.steps.length - 1 ? <button className="btn" onClick={() => setStep(step + 1)}>Done — next step →</button>
            : <button className="btn" onClick={() => { setWalking(false); setMsg('🎉 Dish complete — enjoy your ' + recipe.title + '!'); }}>✓ Finish — dish complete!</button>}
          <button className="btn-secondary" onClick={() => setWalking(false)}>View all steps</button>
        </div></div>}
    </article>}
  </section>;
}
