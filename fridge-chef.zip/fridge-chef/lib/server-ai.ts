// Shared server-only AI helpers. Gemini is the ONLY AI provider (per Manan's spec, 2026-10-31).
// AI generation: Gemini -> (caller falls back to the offline library).
// The Dish Guide checks the LOCAL dish database first, then Gemini (see app/api/guide/route.ts).
// OpenAI, OpenRouter, Cerebras, Groq and Muse were all removed from the app by request.
// Never import this from client components — it reads secret env vars.
export type AIProvider = 'gemini';
export const PROVIDER_CHAIN: AIProvider[] = ['gemini'];
export async function fetchWithTimeout(url: string, init: RequestInit, ms = 15000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
  try { return await fetch(url, { ...init, signal: c.signal }); } finally { clearTimeout(t); }
}
export function extractJson(text: string): unknown {
  const match = text.match(/\{[\s\S]*\}/); if (!match) throw new Error('No JSON in AI response');
  return JSON.parse(match[0]);
}
// Verified live 2026-10-31 with a real key: gemini-2.0-flash is RETIRED (404) and gemini-2.5-flash refuses new
// accounts (404) — Google directs new users to gemini-3.8-flash, which can return 503 under demand spikes.
// So callGemini walks a model fallback list instead of trusting one model ID.
export const GEMINI_MODEL_FALLBACKS = ['gemini-3.8-flash', 'gemini-3-flash-preview', 'gemini-flash-latest'];
export async function callGemini(prompt: string): Promise<string> {
  const key = process.env.GEMINI_API_KEY; if (!key) throw new Error('GEMINI_API_KEY not set');
  const primary = process.env.GEMINI_MODEL || GEMINI_MODEL_FALLBACKS[0];
  const models = Array.from(new Set([primary, ...GEMINI_MODEL_FALLBACKS]));
  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await fetchWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.6 } }) });
      if (!res.ok) continue;
      const j = await res.json(); const text = j?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      if (text) return text;
    }
  }
  throw new Error('Gemini failed on all fallback models');
}
/** Call Gemini, the only AI provider. Throws if it fails/is unconfigured — callers then use the offline library. */
export async function callAI(prompt: string): Promise<{ text: string; provider: AIProvider }> {
  return { text: await callGemini(prompt), provider: 'gemini' };
}
/** Which providers have a key configured — booleans/models only, NEVER key values. Safe to expose via /api/ai-status. */
export function providerStatus() {
  return {
    chain: [...PROVIDER_CHAIN, 'offline'] as string[],
    guideFlow: ['local-database', 'gemini'] as string[],
    providers: {
      gemini: { configured: Boolean(process.env.GEMINI_API_KEY), model: process.env.GEMINI_MODEL || 'gemini-3.8-flash', keyEnv: 'GEMINI_API_KEY', getKeyAt: 'Google AI Studio (aistudio.google.com)', notes: 'The only AI provider. Free tier available within Google limits.' },
      offline: { configured: true, model: 'built-in library', keyEnv: null, getKeyAt: null, notes: 'Local dish database (Dish Guide checks it first) and offline recipe pool. Always available, no key, no cost.' },
    },
  };
}
const hits = new Map<string, { count: number; reset: number }>();
export function rateLimited(ip: string, limit = 30) {
  const now = Date.now(); const cur = hits.get(ip);
  if (!cur || now > cur.reset) { hits.set(ip, { count: 1, reset: now + 3600_000 }); return false; }
  cur.count++; return cur.count > limit;
}
