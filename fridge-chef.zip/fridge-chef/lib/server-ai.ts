// Shared server-only AI helpers. Provider chain: Gemini -> OpenRouter (free) -> Cerebras (free) -> Groq (free) -> Muse (paid, optional) -> (caller falls back to offline).
// Never import this from client components — it reads secret env vars.
export type AIProvider = 'gemini' | 'openrouter' | 'cerebras' | 'groq' | 'muse';
// Free providers first, in order. Muse (paid, Meta Model API) is LAST and entirely optional —
// it is only reached when every free provider is unconfigured or fails and a Muse key exists.
export const PROVIDER_CHAIN: AIProvider[] = ['gemini', 'openrouter', 'cerebras', 'groq', 'muse'];
export async function fetchWithTimeout(url: string, init: RequestInit, ms = 15000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
  try { return await fetch(url, { ...init, signal: c.signal }); } finally { clearTimeout(t); }
}
export function extractJson(text: string): unknown {
  const match = text.match(/\{[\s\S]*\}/); if (!match) throw new Error('No JSON in AI response');
  return JSON.parse(match[0]);
}
// Verified live 2026-10-31 with a real key: gemini-2.0-flash is RETIRED (404) and gemini-2.5-flash refuses new
// accounts (404) — Google directs new users to gemini-3.8-flash, which can return 503 under demand spikes.
// So callGemini walks a model fallback list instead of trusting one model ID.
export const GEMINI_MODEL_FALLBACKS = ['gemini-3.8-flash', 'gemini-3-flash-preview', 'gemini-flash-latest'];
export async function callGemini(prompt: string): Promise<string> {
  const key = process.env.GEMINI_API_KEY; if (!key) throw new Error('GEMINI_API_KEY not set');
  const primary = process.env.GEMINI_MODEL || GEMINI_MODEL_FALLBACKS[0];
  const models = Array.from(new Set([primary, ...GEMINI_MODEL_FALLBACKS]));
  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await fetchWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.6 } }) });
      if (!res.ok) continue;
      const j = await res.json(); const text = j?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      if (text) return text;
    }
  }
  throw new Error('Gemini failed on all fallback models');
}
/**
 * Muse via the Meta Model API (dev.meta.ai). OpenAI-compatible Chat Completions:
 * POST https://api.meta.ai/v1/chat/completions, Authorization: Bearer <key>, model muse-wonder-1.0 by default.
 * Key env: MODEL_API_KEY (Meta's documented name) or META_MODEL_API_KEY. Model env: MUSE_MODEL.
 * Paid API ($4 in / $20 out per 1M tokens, no free tier, billing + region eligibility required) — we never send response_format,
 * since JSON mode support is not documented there; the prompt demands JSON-only and extractJson() parses robustly.
 */
export async function callMuse(prompt: string): Promise<string> {
  const key = process.env.META_MODEL_API_KEY || process.env.MODEL_API_KEY; if (!key) throw new Error('MODEL_API_KEY not set');
  const model = process.env.MUSE_MODEL || 'muse-wonder-1.0';
  const res = await fetchWithTimeout('https://api.meta.ai/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` }, body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.6 }) });
  if (!res.ok) throw new Error('Muse failed');
  const j = await res.json(); const text = j?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Muse empty');
  return text;
}
async function callChatCompletions(url: string, key: string, model: string, prompt: string, label: string): Promise<string> {
  const res = await fetchWithTimeout(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` }, body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.6 }) });
  if (!res.ok) throw new Error(`${label} failed`);
  const j = await res.json(); const text = j?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error(`${label} empty`);
  return text;
}
/**
 * OpenRouter (FREE tier, no card): one key, many free models (IDs end in :free).
 * Default models: see OPENROUTER_MODEL_FALLBACKS (the free pool rotates). Free limits ~20 req/min and 50 req/day without credits.
 * Endpoint: POST https://openrouter.ai/api/v1/chat/completions (OpenAI-compatible).
 */
// Free pools rotate and individual models come and go (verified live 2026-10-31:
// meta-llama/llama-3.3-70b-instruct:free currently 404s "unavailable for free", and the
// Gemma free endpoints can be excluded by the account's OpenRouter data-policy/ZDR settings).
// So the default walks known free models and always ends at openrouter/free, the auto-router
// that picks any currently-available free model. Set OPENROUTER_MODEL to pin one model instead.
export const OPENROUTER_MODEL_FALLBACKS = ['google/gemma-4-31b-it:free', 'google/gemma-4-26b-a4b-it:free', 'openrouter/free'];
export async function callOpenRouter(prompt: string): Promise<string> {
  const key = process.env.OPENROUTER_API_KEY; if (!key) throw new Error('OPENROUTER_API_KEY not set');
  const models = process.env.OPENROUTER_MODEL ? [process.env.OPENROUTER_MODEL] : OPENROUTER_MODEL_FALLBACKS;
  let lastError: unknown = null;
  for (const model of models) {
    try { return await callChatCompletions('https://openrouter.ai/api/v1/chat/completions', key, model, prompt, 'OpenRouter'); }
    catch (e) { lastError = e; }
  }
  throw lastError instanceof Error ? lastError : new Error('OpenRouter failed');
}
/**
 * Cerebras (FREE tier): very fast Llama inference, reported ~1M tokens/day free (terms change — check the console).
 * Default model llama-3.3-70b. Endpoint: POST https://api.cerebras.ai/v1/chat/completions (OpenAI-compatible).
 */
export async function callCerebras(prompt: string): Promise<string> {
  const key = process.env.CEREBRAS_API_KEY; if (!key) throw new Error('CEREBRAS_API_KEY not set');
  const model = process.env.CEREBRAS_MODEL || 'llama-3.3-70b';
  return callChatCompletions('https://api.cerebras.ai/v1/chat/completions', key, model, prompt, 'Cerebras');
}
export async function callGroq(prompt: string): Promise<string> {
  const key = process.env.GROQ_API_KEY; if (!key) throw new Error('GROQ_API_KEY not set');
  const model = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
  const res = await fetchWithTimeout('https://api.groq.com/openai/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` }, body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], response_format: { type: 'json_object' }, temperature: 0.6 }) });
  if (!res.ok) throw new Error('Groq failed');
  const j = await res.json(); const text = j?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Groq empty');
  return text;
}
/** Try each provider in PROVIDER_CHAIN order (free first, paid Muse last). Throws if all fail/unconfigured. */
export async function callAI(prompt: string): Promise<{ text: string; provider: AIProvider }> {
  const callers: Record<AIProvider, (p: string) => Promise<string>> = { gemini: callGemini, openrouter: callOpenRouter, cerebras: callCerebras, groq: callGroq, muse: callMuse };
  let lastError: unknown = null;
  for (const provider of PROVIDER_CHAIN) {
    try { return { text: await callers[provider](prompt), provider }; } catch (e) { lastError = e; }
  }
  throw lastError instanceof Error ? lastError : new Error('All AI providers failed');
}
/** Which providers have a key configured — booleans/models only, NEVER key values. Safe to expose via /api/ai-status. */
export function providerStatus() {
  return {
    chain: [...PROVIDER_CHAIN, 'offline'] as string[],
    providers: {
      gemini: { configured: Boolean(process.env.GEMINI_API_KEY), model: process.env.GEMINI_MODEL || 'gemini-3.8-flash', keyEnv: 'GEMINI_API_KEY', getKeyAt: 'Google AI Studio (aistudio.google.com)', notes: 'Free tier available within Google limits.' },
      muse: { configured: Boolean(process.env.META_MODEL_API_KEY || process.env.MODEL_API_KEY), model: process.env.MUSE_MODEL || 'muse-wonder-1.0', keyEnv: 'MODEL_API_KEY', getKeyAt: 'dev.meta.ai → Billing → API keys', notes: 'Meta Model API, paid ($4 in / $20 out per 1M tokens), no free tier, billing + supported region required.' },
      openrouter: { configured: Boolean(process.env.OPENROUTER_API_KEY), model: process.env.OPENROUTER_MODEL || OPENROUTER_MODEL_FALLBACKS.join(' → '), keyEnv: 'OPENROUTER_API_KEY', getKeyAt: 'openrouter.ai -> Keys', notes: 'FREE, no card. One key, many free (:free) models. About 20 req/min and 50 req/day on free models without credits.' },
      cerebras: { configured: Boolean(process.env.CEREBRAS_API_KEY), model: process.env.CEREBRAS_MODEL || 'llama-3.3-70b', keyEnv: 'CEREBRAS_API_KEY', getKeyAt: 'cloud.cerebras.ai -> API Keys', notes: 'FREE tier, very fast Llama inference, reported ~1M tokens/day. Free-tier terms change, check the console.' },
      groq: { configured: Boolean(process.env.GROQ_API_KEY), model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile', keyEnv: 'GROQ_API_KEY', getKeyAt: 'Groq Console (console.groq.com)', notes: 'Free tier available within Groq limits.' },
      offline: { configured: true, model: 'built-in library', keyEnv: null, getKeyAt: null, notes: 'Always available, no key, no cost.' },
    },
  };
}
const hits = new Map<string, { count: number; reset: number }>();
export function rateLimited(ip: string, limit = 30) {
  const now = Date.now(); const cur = hits.get(ip);
  if (!cur || now > cur.reset) { hits.set(ip, { count: 1, reset: now + 3600_000 }); return false; }
  cur.count++; return cur.count > limit;
}
