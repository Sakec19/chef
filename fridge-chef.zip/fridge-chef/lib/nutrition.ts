import type { Nutrition, IngredientQty } from './types';
// Per-100g estimates compiled from USDA FoodData Central typical values for the generic/raw or plain-cooked form.
// Estimates only — variety, brand and cooking method change real values. Not medical advice.
export type FoodCategory = 'protein'|'dairy'|'grain'|'legume'|'vegetable'|'fruit'|'fat'|'pantry'|'herb';
export interface FoodEntry extends Nutrition { per: string; category: FoodCategory; pieceGrams?: number }
const F = (calories: number, protein: number, carbs: number, fat: number, fiber: number, sodium: number, category: FoodCategory, pieceGrams?: number): FoodEntry =>
  ({ calories, protein, carbs, fat, fiber, sodium, per: '100g', category, pieceGrams });

export const FOOD_DB: Record<string, FoodEntry> = {
  // --- Protein ---
  'chicken breast': F(165, 31, 0, 3.6, 0, 74, 'protein', 174), chicken: F(239, 27, 0, 14, 0, 82, 'protein', 174),
  turkey: F(189, 29, 0, 7, 0, 70, 'protein', 174), 'ground beef': F(250, 26, 0, 15, 0, 72, 'protein'),
  beef: F(250, 26, 0, 15, 0, 72, 'protein'), steak: F(271, 25, 0, 19, 0, 72, 'protein'),
  pork: F(242, 27, 0, 14, 0, 62, 'protein'), bacon: F(541, 37, 1.4, 42, 0, 1717, 'protein', 8),
  ham: F(145, 21, 1.5, 5.5, 0, 1203, 'protein'), sausage: F(301, 12, 2.4, 27, 0, 812, 'protein', 75),
  salmon: F(208, 20, 0, 13, 0, 59, 'protein', 170), tuna: F(132, 28, 0, 1, 0, 47, 'protein'),
  cod: F(82, 18, 0, 0.7, 0, 54, 'protein', 170), tilapia: F(129, 26, 0, 2.6, 0, 56, 'protein'),
  shrimp: F(85, 20, 0.2, 0.5, 0, 119, 'protein', 5), sardines: F(208, 25, 0, 11, 0, 505, 'protein'),
  fish: F(120, 22, 0, 3, 0, 60, 'protein', 170),
  egg: F(155, 13, 1.1, 11, 0, 124, 'protein', 50), eggs: F(155, 13, 1.1, 11, 0, 124, 'protein', 50),
  tofu: F(76, 8, 1.9, 4.8, 0.3, 7, 'protein', 85), tempeh: F(193, 19, 9, 11, 1.1, 9, 'protein'),
  seitan: F(143, 25, 4, 1, 0.6, 29, 'protein'),
  // --- Dairy & alternatives ---
  milk: F(42, 3.4, 5, 1, 0, 44, 'dairy'), 'oat milk': F(46, 0.3, 7, 1.9, 0.3, 40, 'dairy'),
  'almond milk': F(15, 0.6, 1.3, 1.1, 0.3, 72, 'dairy'), 'soy milk': F(43, 3.3, 1.7, 1.8, 0.6, 51, 'dairy'),
  yogurt: F(59, 3.5, 4.7, 3.3, 0, 36, 'dairy'), 'greek yogurt': F(97, 9, 3.6, 5, 0, 36, 'dairy'),
  cheese: F(402, 25, 1.3, 33, 0, 621, 'dairy', 28), cheddar: F(402, 25, 1.3, 33, 0, 621, 'dairy', 28),
  mozzarella: F(280, 28, 3.1, 17, 0, 619, 'dairy', 28), parmesan: F(431, 38, 4.1, 29, 0, 1529, 'dairy'),
  'feta cheese': F(264, 14, 4.1, 21, 0, 1116, 'dairy'), feta: F(264, 14, 4.1, 21, 0, 1116, 'dairy'),
  'cream cheese': F(342, 5.9, 4.1, 34, 0, 321, 'dairy'), butter: F(717, 0.9, 0.1, 81, 0, 11, 'dairy'),
  cream: F(195, 2.7, 3.7, 19, 0, 34, 'dairy'), 'sour cream': F(198, 2.4, 4.6, 19, 0, 31, 'dairy'),
  paneer: F(265, 18, 3.6, 20, 0, 18, 'dairy'),
  // --- Grains & breads ---
  rice: F(130, 2.7, 28, 0.3, 0.4, 1, 'grain'), 'brown rice': F(112, 2.6, 24, 0.9, 1.8, 5, 'grain'),
  'basmati rice': F(121, 3.5, 25, 0.4, 0.4, 1, 'grain'), pasta: F(158, 5.8, 31, 0.9, 1.8, 1, 'grain'),
  spaghetti: F(158, 5.8, 31, 0.9, 1.8, 1, 'grain'), noodles: F(138, 4.5, 25, 2.1, 1.2, 378, 'grain'),
  oats: F(389, 16.9, 66, 6.9, 10.6, 2, 'grain'), quinoa: F(120, 4.4, 21, 1.9, 2.8, 7, 'grain'),
  couscous: F(112, 3.8, 23, 0.2, 1.4, 5, 'grain'), bulgur: F(83, 3.1, 19, 0.2, 4.5, 5, 'grain'),
  bread: F(265, 9, 49, 3.2, 2.7, 491, 'grain', 30), tortilla: F(237, 5.7, 40, 5.4, 6.3, 217, 'grain', 45),
  flour: F(364, 10, 76, 1, 2.7, 2, 'grain'), cornmeal: F(370, 7, 79, 1.8, 3.9, 7, 'grain'),
  // --- Legumes ---
  lentils: F(116, 9, 20, 0.4, 7.9, 2, 'legume'), 'black beans': F(91, 6, 16, 0.3, 6.9, 1, 'legume'),
  'kidney beans': F(127, 8.7, 23, 0.5, 7.4, 2, 'legume'), beans: F(127, 8.7, 23, 0.5, 7.4, 2, 'legume'),
  chickpeas: F(164, 9, 27, 2.6, 7.6, 7, 'legume'), hummus: F(166, 7.9, 14, 9.6, 6, 379, 'legume'),
  peas: F(81, 5.4, 14, 0.4, 5.7, 5, 'legume'), edamame: F(121, 11.9, 8.9, 5.2, 5.2, 6, 'legume'),
  'peanut butter': F(588, 25, 20, 50, 6, 17, 'fat'), peanuts: F(567, 26, 16, 49, 8.5, 18, 'legume', 1),
  // --- Vegetables ---
  potato: F(77, 2, 17, 0.1, 2.2, 6, 'vegetable', 150), 'sweet potato': F(86, 1.6, 20, 0.1, 3, 55, 'vegetable', 130),
  tomato: F(18, 0.9, 3.9, 0.2, 1.2, 5, 'vegetable', 123), 'cherry tomato': F(18, 0.9, 3.9, 0.2, 1.2, 5, 'vegetable', 17),
  onion: F(40, 1.1, 9.3, 0.1, 1.7, 4, 'vegetable', 110), garlic: F(149, 6.4, 33, 0.5, 2.1, 17, 'vegetable', 3),
  spinach: F(23, 2.9, 3.6, 0.4, 2.2, 79, 'vegetable'), kale: F(49, 4.3, 8.8, 0.9, 3.6, 43, 'vegetable'),
  lettuce: F(15, 1.4, 2.9, 0.2, 1.3, 28, 'vegetable'), broccoli: F(34, 2.8, 6.6, 0.4, 2.6, 33, 'vegetable', 31),
  cauliflower: F(25, 1.9, 5, 0.3, 2, 30, 'vegetable'), carrot: F(41, 0.9, 10, 0.2, 2.8, 69, 'vegetable', 61),
  'bell pepper': F(31, 1, 6, 0.3, 2.1, 4, 'vegetable', 119), pepper: F(31, 1, 6, 0.3, 2.1, 4, 'vegetable', 119),
  zucchini: F(17, 1.2, 3.1, 0.3, 1, 8, 'vegetable', 196), courgette: F(17, 1.2, 3.1, 0.3, 1, 8, 'vegetable', 196),
  cucumber: F(15, 0.7, 3.6, 0.1, 0.5, 2, 'vegetable', 301), mushroom: F(22, 3.1, 3.3, 0.3, 1, 5, 'vegetable', 12),
  corn: F(96, 3.4, 21, 1.5, 2.4, 15, 'vegetable'), 'green beans': F(31, 1.8, 7, 0.1, 3.4, 6, 'vegetable'),
  cabbage: F(25, 1.3, 5.8, 0.1, 2.5, 18, 'vegetable'), eggplant: F(25, 1, 6, 0.2, 3, 2, 'vegetable', 458),
  aubergine: F(25, 1, 6, 0.2, 3, 2, 'vegetable', 458), avocado: F(160, 2, 9, 15, 7, 7, 'vegetable', 150),
  ginger: F(80, 1.8, 18, 0.8, 2, 13, 'vegetable', 5), chili: F(40, 1.9, 9.5, 0.4, 1.5, 9, 'vegetable', 45),
  celery: F(16, 0.7, 3, 0.2, 1.6, 80, 'vegetable', 40), pumpkin: F(26, 1, 6.5, 0.1, 0.5, 1, 'vegetable'),
  beetroot: F(43, 1.6, 10, 0.2, 2.8, 78, 'vegetable', 82),
  // --- Fruit ---
  banana: F(89, 1.1, 23, 0.3, 2.6, 1, 'fruit', 118), apple: F(52, 0.3, 14, 0.2, 2.4, 1, 'fruit', 182),
  orange: F(47, 0.9, 12, 0.1, 2.4, 0, 'fruit', 131), lemon: F(29, 1.1, 9.3, 0.3, 2.8, 2, 'fruit', 58),
  lime: F(30, 0.7, 11, 0.2, 2.8, 2, 'fruit', 67), mango: F(60, 0.8, 15, 0.4, 1.6, 1, 'fruit', 336),
  strawberries: F(32, 0.7, 7.7, 0.3, 2, 1, 'fruit', 12), strawberry: F(32, 0.7, 7.7, 0.3, 2, 1, 'fruit', 12),
  blueberries: F(57, 0.7, 14, 0.3, 2.4, 1, 'fruit', 1), blueberry: F(57, 0.7, 14, 0.3, 2.4, 1, 'fruit', 1),
  grapes: F(69, 0.7, 18, 0.2, 0.9, 2, 'fruit', 5), pineapple: F(50, 0.5, 13, 0.1, 1.4, 1, 'fruit', 84),
  peach: F(39, 0.9, 10, 0.3, 1.5, 0, 'fruit', 150), pear: F(57, 0.4, 15, 0.1, 3.1, 1, 'fruit', 178),
  watermelon: F(30, 0.6, 7.6, 0.2, 0.4, 1, 'fruit'),
  // --- Fats, nuts, seeds ---
  'olive oil': F(884, 0, 0, 100, 0, 2, 'fat'), oil: F(884, 0, 0, 100, 0, 2, 'fat'),
  'coconut milk': F(197, 2.1, 2.8, 21, 0, 13, 'dairy'), almonds: F(579, 21, 22, 50, 12.5, 1, 'fat', 1),
  almond: F(579, 21, 22, 50, 12.5, 1, 'fat', 1), walnuts: F(654, 15, 14, 65, 6.7, 2, 'fat', 4),
  walnut: F(654, 15, 14, 65, 6.7, 2, 'fat', 4), cashews: F(553, 18, 30, 44, 3.3, 12, 'fat', 2),
  'chia seeds': F(486, 17, 42, 31, 34.4, 16, 'fat'), 'flax seeds': F(534, 18, 29, 42, 27.3, 30, 'fat'),
  'sesame oil': F(884, 0, 0, 100, 0, 0, 'fat'), tahini: F(595, 17, 21, 54, 5, 35, 'fat'),
  // --- Pantry, herbs, condiments ---
  sugar: F(387, 0, 100, 0, 0, 1, 'pantry'), honey: F(304, 0.3, 82, 0, 0.2, 4, 'pantry'),
  'soy sauce': F(53, 8.1, 4.9, 0.6, 0.8, 5493, 'pantry'), 'tomato paste': F(82, 4.3, 19, 0.5, 4.1, 38, 'pantry'),
  'canned tomatoes': F(16, 0.8, 3.5, 0.1, 1.1, 120, 'pantry'), ketchup: F(112, 1.3, 27, 0.1, 0.3, 907, 'pantry'),
  mayonnaise: F(680, 1, 0.6, 75, 0, 635, 'pantry'), mustard: F(60, 3.7, 5.8, 3.4, 4, 1104, 'pantry'),
  basil: F(23, 3.2, 2.7, 0.6, 1.6, 4, 'herb'), parsley: F(36, 3, 6.3, 0.8, 3.3, 56, 'herb'),
  cilantro: F(23, 2.1, 3.7, 0.5, 2.8, 46, 'herb'), coriander: F(23, 2.1, 3.7, 0.5, 2.8, 46, 'herb'),
  cumin: F(375, 18, 44, 22, 10.5, 168, 'herb'), paprika: F(282, 14, 54, 13, 34.9, 68, 'herb'),
  turmeric: F(312, 9.7, 67, 3.3, 22.7, 27, 'herb'), cinnamon: F(247, 4, 81, 1.2, 53.1, 10, 'herb'),
  'vegetable stock': F(5, 0.2, 0.8, 0.1, 0, 340, 'pantry'), 'chicken stock': F(7, 0.6, 0.7, 0.2, 0, 320, 'pantry'),
};
// Sorted longest-first so 'sweet potato' beats 'potato', 'chicken breast' beats 'chicken', 'oat milk' beats 'milk'/'oats'.
const SORTED_KEYS = Object.keys(FOOD_DB).sort((a, b) => b.length - a.length);
export function lookupFood(name: string) {
  const n = name.toLowerCase();
  const key = SORTED_KEYS.find(k => n.includes(k));
  return key ? { key, ...FOOD_DB[key] } : null;
}
export function gramsFor(ing: IngredientQty): number {
  const u = ing.unit.toLowerCase(); const food = lookupFood(ing.name);
  if (u === 'g' || u === 'gram' || u === 'grams') return ing.quantity;
  if (u === 'kg') return ing.quantity * 1000;
  if (u === 'oz') return ing.quantity * 28.35;
  if (u === 'lb' || u === 'lbs') return ing.quantity * 453.6;
  if (u === 'ml') return ing.quantity;
  if (u === 'l' || u === 'liter') return ing.quantity * 1000;
  if (u === 'cup' || u === 'cups') return ing.quantity * 200;
  if (u === 'tbsp' || u === 'tablespoon' || u === 'tablespoons') return ing.quantity * 15;
  if (u === 'tsp' || u === 'teaspoon' || u === 'teaspoons') return ing.quantity * 5;
  if (u === 'piece' || u === 'pieces' || u === 'whole' || u === 'clove' || u === 'cloves' || u === '') return ing.quantity * (food?.pieceGrams ?? 100);
  if (u === 'can' || u === 'cans') return ing.quantity * 400;
  return ing.quantity * 100;
}
/** Ingredient-level nutrition for a recipe, scaled per serving. Unknown foods contribute 0 and are not invented. */
export function calculateNutrition(ingredients: IngredientQty[], servings: number): Nutrition {
  const total: Nutrition = { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sodium: 0 };
  for (const ing of ingredients) {
    const food = lookupFood(ing.name); if (!food) continue;
    const factor = gramsFor(ing) / 100;
    total.calories += food.calories * factor; total.protein += food.protein * factor;
    total.carbs += food.carbs * factor; total.fat += food.fat * factor;
    total.fiber = (total.fiber || 0) + (food.fiber || 0) * factor;
    total.sodium = (total.sodium || 0) + (food.sodium || 0) * factor;
  }
  const s = Math.max(1, servings);
  return { calories: Math.round(total.calories / s), protein: Math.round((total.protein / s) * 10) / 10, carbs: Math.round((total.carbs / s) * 10) / 10, fat: Math.round((total.fat / s) * 10) / 10, fiber: Math.round(((total.fiber || 0) / s) * 10) / 10, sodium: Math.round((total.sodium || 0) / s) };
}
/** How many of the recipe's ingredients were found in the DB — lets the UI be honest about estimate coverage. */
export function nutritionCoverage(ingredients: IngredientQty[]): number {
  if (!ingredients.length) return 0;
  return Math.round((ingredients.filter(i => lookupFood(i.name)).length / ingredients.length) * 100);
}
export function scaleNutrition(n: Nutrition, fromServings: number, toServings: number): Nutrition {
  const f = toServings / Math.max(1, fromServings);
  return { calories: Math.round(n.calories * f), protein: Math.round(n.protein * f * 10) / 10, carbs: Math.round(n.carbs * f * 10) / 10, fat: Math.round(n.fat * f * 10) / 10, fiber: n.fiber ? Math.round(n.fiber * f * 10) / 10 : undefined, sodium: n.sodium ? Math.round(n.sodium * f) : undefined };
}

// --- Prices: USD estimate per 100g (per piece where pieceGrams is the natural buying unit is converted via gramsFor). ---
// All flagged certain:false — these are planning estimates, never verified store prices.
export const PRICES: Record<string, { pricePer100g: number; certain: boolean }> = {};
function setPrices(map: Record<string, number>) { for (const [k, v] of Object.entries(map)) PRICES[k] = { pricePer100g: v, certain: false }; }
setPrices({
  'chicken breast': 1.10, chicken: 0.85, turkey: 1.00, 'ground beef': 1.20, beef: 1.40, steak: 1.80, pork: 0.95, bacon: 1.60, ham: 1.30, sausage: 1.10,
  salmon: 2.20, tuna: 1.60, cod: 1.70, tilapia: 1.20, shrimp: 2.00, sardines: 1.10, fish: 1.50, egg: 0.60, eggs: 0.60, tofu: 0.80, tempeh: 1.20, seitan: 1.40,
  milk: 0.12, 'oat milk': 0.25, 'almond milk': 0.25, 'soy milk': 0.20, yogurt: 0.45, 'greek yogurt': 0.70, cheese: 1.20, cheddar: 1.20, mozzarella: 1.10,
  parmesan: 2.00, feta: 1.50, 'feta cheese': 1.50, 'cream cheese': 0.90, butter: 1.10, cream: 0.60, 'sour cream': 0.60, paneer: 1.40, 'coconut milk': 0.35,
  rice: 0.18, 'brown rice': 0.25, 'basmati rice': 0.30, pasta: 0.22, spaghetti: 0.22, noodles: 0.40, oats: 0.15, quinoa: 0.60, couscous: 0.45, bulgur: 0.35,
  bread: 0.45, tortilla: 0.55, flour: 0.10, cornmeal: 0.15,
  lentils: 0.25, 'black beans': 0.30, 'kidney beans': 0.30, beans: 0.30, chickpeas: 0.30, hummus: 0.80, peas: 0.35, edamame: 0.80, 'peanut butter': 0.60, peanuts: 0.70,
  potato: 0.20, 'sweet potato': 0.30, tomato: 0.45, 'cherry tomato': 0.70, onion: 0.25, garlic: 0.80, spinach: 0.70, kale: 0.60, lettuce: 0.50, broccoli: 0.45,
  cauliflower: 0.35, carrot: 0.25, 'bell pepper': 0.60, pepper: 0.60, zucchini: 0.35, courgette: 0.35, cucumber: 0.35, mushroom: 0.80, corn: 0.35,
  'green beans': 0.50, cabbage: 0.15, eggplant: 0.40, aubergine: 0.40, avocado: 0.90, ginger: 0.90, chili: 0.80, celery: 0.30, pumpkin: 0.25, beetroot: 0.30,
  banana: 0.15, apple: 0.35, orange: 0.30, lemon: 0.50, lime: 0.60, mango: 0.50, strawberries: 0.80, strawberry: 0.80, blueberries: 1.20, blueberry: 1.20,
  grapes: 0.50, pineapple: 0.30, peach: 0.50, pear: 0.40, watermelon: 0.12,
  'olive oil': 0.90, oil: 0.40, almonds: 1.40, almond: 1.40, walnuts: 1.50, walnut: 1.50, cashews: 1.40, 'chia seeds': 1.20, 'flax seeds': 0.90, 'sesame oil': 1.20, tahini: 1.00,
  sugar: 0.10, honey: 0.90, 'soy sauce': 0.40, 'tomato paste': 0.40, 'canned tomatoes': 0.25, ketchup: 0.35, mayonnaise: 0.50, mustard: 0.50,
  basil: 1.50, parsley: 0.80, cilantro: 0.80, coriander: 0.80, cumin: 1.50, paprika: 1.50, turmeric: 1.20, cinnamon: 1.50, 'vegetable stock': 0.15, 'chicken stock': 0.15,
});
const SORTED_PRICE_KEYS = Object.keys(PRICES).sort((a, b) => b.length - a.length);
export function estimatePrice(name: string) {
  const n = name.toLowerCase(); const k = SORTED_PRICE_KEYS.find(x => n.includes(x));
  return k ? { price: PRICES[k].pricePer100g, pricePer100g: PRICES[k].pricePer100g, certain: false } : { price: 0.5, pricePer100g: 0.5, certain: false };
}
/** Price for ONE of the given unit (e.g. per gram, per kg, per piece) so quantity × unitPrice = realistic line total. */
export function priceForUnit(name: string, unit: string): number {
  const per100g = estimatePrice(name).pricePer100g;
  const gramsOfOneUnit = gramsFor({ name, quantity: 1, unit });
  return Math.round((per100g * gramsOfOneUnit / 100) * 10000) / 10000;
}
/** Realistic estimated line cost for a quantity+unit of an ingredient. */
export function estimateLineCost(name: string, quantity: number, unit: string): number {
  return Math.round(quantity * priceForUnit(name, unit) * 100) / 100;
}
