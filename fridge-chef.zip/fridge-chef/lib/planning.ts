import type { PantryItem, Recipe, ShopItem } from './types';
import { aggregate, convert, normalizeName } from './units';
import { priceForUnit, lookupFood } from './nutrition';
import { OFFLINE_RECIPES, recipesForCuisines } from './offline-recipes';

export function buildShoppingList(recipes: Recipe[], pantry: PantryItem[]): ShopItem[] {
  const needed = aggregate(recipes.flatMap(r => r.ingredients.filter(i => !i.staple).map(i => ({ name: i.name, quantity: i.quantity, unit: i.unit, category: guessCategory(i.name) }))));
  const out: ShopItem[] = [];
  for (const n of needed) {
    let remaining = n.quantity;
    for (const p of pantry.filter(p => normalizeName(p.name) === normalizeName(n.name))) {
      const c = convert(p.quantity, p.unit, n.unit); if (c !== null) remaining -= c;
    }
    if (remaining <= 0.01) continue;
    out.push({ id: 'shop-' + normalizeName(n.name) + '-' + n.unit, name: n.name, quantity: Math.round(remaining * 100) / 100, unit: n.unit, category: n.category, unitPrice: priceForUnit(n.name, n.unit), priceCertain: false, checked: false });
  }
  return out.sort((a,b) => a.category.localeCompare(b.category));
}
export function guessCategory(name: string) {
  const food = lookupFood(name);
  if (food) {
    if (food.category === 'protein') return 'Protein';
    if (food.category === 'dairy') return 'Dairy';
    if (food.category === 'vegetable' || food.category === 'fruit') return 'Produce';
    if (food.category === 'grain' || food.category === 'legume' || food.category === 'pantry' || food.category === 'fat' || food.category === 'herb') return 'Pantry staples';
  }
  return 'Other';
}
export function totalCost(items: ShopItem[]) { return Math.round(items.reduce((s, i) => s + i.quantity * i.unitPrice, 0) * 100) / 100; }
export interface MonthPlanResult { days: { date: string; recipe: Recipe | null; restaurant: boolean; locked?: boolean }[]; groceryCost: number; restaurantCost: number; totalCost: number; overBudget: number; fitsBudget: boolean }
export function planMonth(year: number, month: number, opts: { budget: number; restaurantNights: number; restaurantCostPerNight?: number; allowRepeats: boolean; cuisines?: string[] }): MonthPlanResult {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const perNight = opts.restaurantCostPerNight ?? 25;
  const days: MonthPlanResult['days'] = [];
  let grocery = 0;
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month, d).toISOString().slice(0, 10);
    const isRestaurant = d > daysInMonth - opts.restaurantNights;
    if (isRestaurant) { days.push({ date, recipe: null, restaurant: true }); continue; }
    const pool = recipesForCuisines(opts.cuisines || []);
    const recipe = pool[opts.allowRepeats ? (d % pool.length) : (d - 1) % pool.length];
    grocery += recipe.estimatedCost; days.push({ date, recipe, restaurant: false });
  }
  grocery = Math.round(grocery * 100) / 100;
  const restaurantCost = opts.restaurantNights * perNight;
  const total = grocery + restaurantCost;
  // Honest budget logic: never claim fit unless calculated total <= budget
  return { days, groceryCost: grocery, restaurantCost, totalCost: total, fitsBudget: total <= opts.budget, overBudget: Math.max(0, Math.round((total - opts.budget) * 100) / 100) };
}
export function daysUntilExpiry(item: PantryItem): number | null { if (!item.expiryDate) return null; return Math.ceil((new Date(item.expiryDate).getTime() - Date.now()) / 86400000); }
export function deductPantry(pantry: PantryItem[], recipe: Recipe): PantryItem[] {
  // Only call after explicit user confirmation. Never goes negative.
  return pantry.map(p => {
    const need = recipe.ingredients.find(i => normalizeName(i.name) === normalizeName(p.name));
    if (!need) return p;
    const c = convert(need.quantity, need.unit, p.unit); if (c === null) return p;
    return { ...p, quantity: Math.max(0, Math.round((p.quantity - c) * 100) / 100) };
  });
}
