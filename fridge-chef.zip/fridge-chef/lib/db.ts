// IndexedDB wrapper with versioning/migrations. DB v1: stores kv, pantry, history, recipes, plans, shop, settings
const DB_NAME = 'fridge-chef'; const DB_VERSION = 1;
function openDB(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => { const db = req.result; ['kv','pantry','history','recipes','plans','shop'].forEach(s => { if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'id' }); }); };
    req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error);
  });
}
async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDB();
  return new Promise((res, rej) => { const t = db.transaction(store, mode); const r = fn(t.objectStore(store)); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}
export const idb = {
  getAll: <T,>(store: string) => tx<T[]>(store, 'readonly', s => s.getAll() as unknown as IDBRequest<T[]>),
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  put: (store: string, value: any) => tx(store, 'readwrite', s => s.put(value)),
  del: (store: string, id: string) => tx(store, 'readwrite', s => s.delete(id)),
  clear: (store: string) => tx(store, 'readwrite', s => s.clear()),
};
export async function exportAll() {
  const [pantry, history, recipes, plans, shop] = await Promise.all([idb.getAll('pantry'), idb.getAll('history'), idb.getAll('recipes'), idb.getAll('plans'), idb.getAll('shop')]);
  return { app: 'fridge-chef', version: 1, exportedAt: new Date().toISOString(), pantry, history, recipes, plans, shop, settings: typeof localStorage !== 'undefined' ? localStorage.getItem('fc-settings') : null };
}
export async function importAll(data: ReturnType<typeof Object> & Record<string, unknown>) {
  const d = data as unknown as Awaited<ReturnType<typeof exportAll>>;
  if (d.app !== 'fridge-chef') throw new Error('Not a Fridge Chef backup');
  for (const store of ['pantry','history','recipes','plans','shop'] as const) { await idb.clear(store); for (const item of (d[store] as {id:string}[]) || []) await idb.put(store, item); }
  if (d.settings && typeof localStorage !== 'undefined') localStorage.setItem('fc-settings', d.settings as string);
}
export function uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
