export type Diet = 'omnivore'|'vegetarian'|'vegetarian-no-egg'|'vegan';
export type Location = 'fridge'|'freezer'|'shelf';
export interface IngredientQty { name: string; quantity: number; unit: string; optional?: boolean; staple?: boolean }
export interface Nutrition { calories: number; protein: number; carbs: number; fat: number; fiber?: number; sodium?: number }
export interface Recipe {
  id: string; title: string; description: string; cuisine: string; mealType: string;
  timeMinutes: number; servings: number; difficulty: 'easy'|'medium'|'hard';
  ingredients: IngredientQty[]; steps: string[]; nutrition: Nutrition;
  benefits: string[]; tags: string[]; source: 'gemini'|'openrouter'|'cerebras'|'groq'|'muse'|'offline'|'saved';
  estimatedCost: number;
}
export interface PantryItem {
  id: string; name: string; quantity: number; unit: string; category: string;
  location: Location; purchaseDate?: string; expiryDate?: string; createdAt: number;
}
export interface HistoryEntry { id: string; pantryId: string; name: string; delta: number; unit: string; reason: string; at: number }
export interface ShopItem { id: string; name: string; quantity: number; unit: string; category: string; unitPrice: number; priceCertain: boolean; checked: boolean; store?: string }
export interface GenerateRequest {
  ingredients: string[]; diet: Diet; allergens: string[];
  /** Specific cuisines from lib/cuisines.ts (e.g. 'Punjabi', 'Gujarati'). Never generic labels like 'Indian'. */
  cuisines?: string[];
  /** @deprecated legacy single free-text cuisine — use cuisines */
  cuisine?: string; mealType?: string;
  maxTime?: number; servings: number; maxCalories?: number; minProtein?: number; skill?: string;
}
export interface DishGuideRequest { dish: string; servings: number; diet?: Diet; allergens?: string[] }
