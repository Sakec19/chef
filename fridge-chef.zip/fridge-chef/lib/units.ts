// Safe unit conversions only within same dimension. Never convert count<->weight etc.
const WEIGHT_G: Record<string, number> = { g: 1, gram: 1, grams: 1, kg: 1000, oz: 28.35, lb: 453.6, lbs: 453.6 };
const VOLUME_ML: Record<string, number> = { ml: 1, l: 1000, liter: 1000, cup: 240, cups: 240, tbsp: 15, tablespoon: 15, tablespoons: 15, tsp: 5, teaspoon: 5, teaspoons: 5 };
export function normalizeName(s: string) { return s.trim().toLowerCase().replace(/\s+/g, ' '); }
export function convert(qty: number, from: string, to: string): number | null {
  const f = from.toLowerCase(), t = to.toLowerCase();
  if (f === t) return qty;
  if (WEIGHT_G[f] && WEIGHT_G[t]) return (qty * WEIGHT_G[f]) / WEIGHT_G[t];
  if (VOLUME_ML[f] && VOLUME_ML[t]) return (qty * VOLUME_ML[f]) / VOLUME_ML[t];
  return null; // unsafe / incompatible
}
export function canConvert(from: string, to: string) { return convert(1, from, to) !== null; }
/** Aggregate identical compatible ingredients; incompatible units stay separate. */
export function aggregate<T extends { name: string; quantity: number; unit: string }>(items: T[]): T[] {
  const out: T[] = [];
  for (const it of items) {
    const key = normalizeName(it.name);
    const match = out.find(o => normalizeName(o.name) === key && canConvert(it.unit, o.unit));
    if (match) { const c = convert(it.quantity, it.unit, match.unit)!; match.quantity = Math.round((match.quantity + c) * 100) / 100; }
    else out.push({ ...it });
  }
  return out;
}
