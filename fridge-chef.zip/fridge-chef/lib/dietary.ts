import type { Diet, Recipe } from './types';
const MEAT = ['chicken','beef','pork','lamb','salmon','fish','tuna','shrimp','bacon','ham','turkey','sausage'];
const ANIMAL = [...MEAT, 'egg','eggs','milk','cheese','butter','yogurt','cream','honey'];
export function forbiddenFor(diet: Diet): string[] {
  if (diet === 'vegan') return ANIMAL;
  if (diet === 'vegetarian') return MEAT;
  if (diet === 'vegetarian-no-egg') return [...MEAT, 'egg','eggs'];
  return [];
}
export function violatesDiet(recipe: Recipe, diet: Diet, allergens: string[] = []): string[] {
  const bad = [...forbiddenFor(diet), ...allergens.map(a => a.toLowerCase())];
  const hits: string[] = [];
  for (const ing of recipe.ingredients) {
    const n = ing.name.toLowerCase();
    for (const b of bad) if (n.includes(b)) hits.push(ing.name);
  }
  return hits;
}
export function validateRecipes(recipes: Recipe[], diet: Diet, allergens: string[] = []): Recipe[] {
  return recipes.filter(r => violatesDiet(r, diet, allergens).length === 0 && r.title && Array.isArray(r.steps) && r.steps.length > 0 && Array.isArray(r.ingredients) && r.ingredients.length > 0);
}
export function parseIngredients(text: string): string[] {
  return text.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean).slice(0, 50);
}
