// Specific cuisine taxonomy. Deliberately NO umbrella labels like "Indian", "Asian", "Chinese" or "Italian" alone —
// every option is a regional / style-specific cuisine, because a Punjabi dhaba curry, a Gujarati thali and
// Mumbai street chaat are not interchangeable. The AI prompt and validators use these exact names.
export interface CuisineGroup { group: string; cuisines: string[] }
export const CUISINE_GROUPS: CuisineGroup[] = [
  { group: 'India — Regional', cuisines: ['Punjabi', 'Gujarati', 'Bengali', 'Maharashtrian', 'Rajasthani', 'Kashmiri', 'Goan', 'Hyderabadi', 'Chettinad', 'Tamil', 'Kerala', 'Assamese', 'Mughlai', 'Awadhi', 'Sindhi', 'Parsi'] },
  { group: 'India — Street & Fast Food', cuisines: ['Indian Street Food (Chaat)', 'Indian Fast Food', 'Indo-Chinese', 'Mumbai Street Food', 'Delhi Street Food', 'Kolkata Street Food', 'South Indian Tiffin'] },
  { group: 'South & Southeast Asia', cuisines: ['Pakistani (Lahori)', 'Pakistani (Karachi)', 'Bangladeshi', 'Sri Lankan', 'Nepali', 'Thai — Central', 'Thai — Isan', 'Thai — Northern', 'Vietnamese — Northern', 'Vietnamese — Southern', 'Malaysian', 'Singaporean', 'Indonesian', 'Filipino'] },
  { group: 'East Asia', cuisines: ['Cantonese', 'Sichuan', 'Hunan', 'Taiwanese', 'Japanese — Home Style', 'Japanese — Izakaya', 'Korean', 'Mongolian'] },
  { group: 'Europe', cuisines: ['Neapolitan', 'Roman', 'Sicilian', 'Tuscan', 'French — Bistro', 'French — Provençal', 'Spanish — Andalusian', 'Spanish — Basque', 'Portuguese', 'Greek — Island', 'Greek — Mainland', 'British', 'Irish', 'German', 'Polish', 'Hungarian', 'Scandinavian'] },
  { group: 'Middle East & Africa', cuisines: ['Lebanese', 'Turkish — Anatolian', 'Turkish — Ottoman', 'Persian', 'Israeli', 'Moroccan', 'Egyptian', 'Ethiopian', 'West African', 'South African'] },
  { group: 'Americas & Caribbean', cuisines: ['Mexican — Oaxacan', 'Mexican — Yucatecan', 'Tex-Mex', 'Southern US', 'Cajun & Creole', 'Texan BBQ', 'Peruvian', 'Brazilian', 'Argentinian', 'Cuban', 'Jamaican'] },
];
export const ALL_CUISINES: string[] = CUISINE_GROUPS.flatMap(g => g.cuisines);
// Labels that must never appear as a recipe cuisine — too general to be useful.
export const BANNED_GENERIC_LABELS = ['indian', 'asian', 'chinese', 'italian', 'mexican', 'thai', 'japanese', 'french', 'spanish', 'greek', 'mediterranean', 'european', 'african', 'american', 'fusion', 'continental'];
export function isSpecificCuisine(name: string): boolean {
  return !BANNED_GENERIC_LABELS.includes(name.trim().toLowerCase());
}
export function isKnownCuisine(name: string): boolean {
  return ALL_CUISINES.some(c => c.toLowerCase() === name.trim().toLowerCase());
}
/** Keep only valid, specific cuisines from user/API input (case-insensitive, returns canonical spelling). */
export function sanitizeCuisines(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  const out: string[] = [];
  for (const raw of input.slice(0, 12)) {
    const match = ALL_CUISINES.find(c => c.toLowerCase() === String(raw).trim().toLowerCase());
    if (match && !out.includes(match)) out.push(match);
  }
  return out;
}
export function recipeMatchesCuisines(cuisine: string, selected: string[]): boolean {
  if (!selected.length) return true;
  const c = cuisine.toLowerCase();
  return selected.some(s => c === s.toLowerCase() || c.includes(s.toLowerCase()) || s.toLowerCase().includes(c));
}
export function groupOf(cuisine: string): string | null {
  const g = CUISINE_GROUPS.find(g => g.cuisines.some(c => c.toLowerCase() === cuisine.toLowerCase()));
  return g ? g.group : null;
}
