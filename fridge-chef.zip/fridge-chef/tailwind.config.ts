import type { Config } from 'tailwindcss';
const config: Config = {
  darkMode: 'class',
  content: ['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { cream:'#FFF8EC', forest:'#1E3D2F', forest2:'#2A5A44', sage:'#8FB996', sageLight:'#DCEBDD', warm:'#E8833A', ink:'#1C2420' },
    fontFamily: { serif:['Georgia','serif'], sans:['system-ui','sans-serif'] },
    borderRadius: { xl2:'1.25rem' }
  }},
  plugins: []
};
export default config;
