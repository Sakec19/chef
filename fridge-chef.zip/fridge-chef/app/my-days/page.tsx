'use client';
import { useEffect, useState } from 'react'; import { OFFLINE_RECIPES, recipesForCuisines } from '@/lib/offline-recipes'; import CuisinePicker from '@/components/CuisinePicker'; import { idb, uid } from '@/lib/db'; import { buildShoppingList } from '@/lib/planning'; import RecipeCard from '@/components/RecipeCard';
export default function MyDaysPage() {
  const [dates, setDates] = useState<string[]>([]); const [pick, setPick] = useState(''); const [servings, setServings] = useState(2); const [msg, setMsg] = useState('');
  useEffect(() => { const s = localStorage.getItem('fc-my-days'); if (s) setDates(JSON.parse(s)); }, []);
  function saveDates(d: string[]) { setDates(d); localStorage.setItem('fc-my-days', JSON.stringify(d)); idb.put('plans', { id: 'my-days', dates: d }).catch(() => {}); }
  function mealsFor(date: string, offset = 0) { const pool = recipesForCuisines(cuisines); const base = Math.abs(date.split('').reduce((a, c) => a + c.charCodeAt(0), 0)) + offset; return { breakfast: pool[base % pool.length], lunch: pool[(base + 2) % pool.length], dinner: pool[(base + 4) % pool.length] }; }
  const [swaps, setSwaps] = useState<Record<string, number>>({}); const [cuisines, setCuisines] = useState<string[]>([]);
  async function toShop() { const recipes = dates.flatMap(d => { const m = mealsFor(d, swaps[d] || 0); return [m.breakfast, m.lunch, m.dinner]; }); const items = buildShoppingList(recipes, []); for (const i of items) await idb.put('shop', i); setMsg(`Added combined shopping list for ${dates.length} day(s): ${items.length} items.`); }
  return <div className="space-y-5"><h1 className="font-serif text-3xl font-bold">My Days</h1><p className="text-sm opacity-80">Pick any dates. Get breakfast, lunch and dinner for each — saved offline.</p>
    <section className="card flex flex-wrap gap-3 items-end"><label className="text-sm font-semibold">Add a date<input type="date" className="input mt-1" value={pick} onChange={e => setPick(e.target.value)} /></label>
    <label className="text-sm font-semibold">Servings<input type="number" min={1} max={12} className="input mt-1 !w-24" value={servings} onChange={e => setServings(Number(e.target.value))} /></label>
    <button className="btn" onClick={() => { if (pick && !dates.includes(pick)) saveDates([...dates, pick].sort()); }}>Add day</button>
    {dates.length > 0 && <button className="btn-secondary" onClick={toShop}>🛒 Combined shopping list</button>}</section>
    <section className="card"><CuisinePicker selected={cuisines} onChange={setCuisines} label="Menu cuisines for my days (specific regions & styles)" /></section>
    {msg && <p role="status" className="card text-sm">{msg}</p>}
    {dates.length === 0 && <div className="card text-center py-10"><p className="text-4xl">🗓️</p><p className="font-semibold mt-2">No days selected yet</p><p className="text-sm opacity-70">Add a date above to plan its meals.</p></div>}
    {dates.map(d => { const m = mealsFor(d, swaps[d] || 0); const total = [m.breakfast, m.lunch, m.dinner].reduce((s, r) => s + r.nutrition.calories, 0);
      return <section key={d} className="space-y-3"><div className="flex items-center justify-between flex-wrap gap-2"><h2 className="font-serif text-2xl font-bold">{d}</h2><span className="text-sm">Day total (est.): <strong>{total} kcal</strong></span><span className="flex gap-2"><button className="btn-secondary" onClick={() => setSwaps(p => ({ ...p, [d]: (p[d] || 0) + 1 }))}>↻ Regenerate day</button><button className="btn-secondary" onClick={() => saveDates(dates.filter(x => x !== d))}>Remove</button></span></div>
      {(['Breakfast', m.breakfast] as const).length && <><p className="font-bold">Breakfast</p><RecipeCard recipe={m.breakfast} /></>}
      <p className="font-bold">Lunch</p><RecipeCard recipe={m.lunch} /><p className="font-bold">Dinner</p><RecipeCard recipe={m.dinner} /></section>; })}
  </div>;
}
