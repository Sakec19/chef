'use client';
import { useEffect, useState } from 'react'; import RecipeCard from '@/components/RecipeCard';
import { OFFLINE_RECIPES, offlineGenerate } from '@/lib/offline-recipes'; import { parseIngredients } from '@/lib/dietary';
import { idb, uid } from '@/lib/db'; import CuisinePicker from '@/components/CuisinePicker'; import DishGuide from '@/components/DishGuide'; import { buildShoppingList } from '@/lib/planning'; import type { Diet, PantryItem, Recipe } from '@/lib/types';

export default function CookPage() {
  const [text, setText] = useState(''); const [diet, setDiet] = useState<Diet>('omnivore'); const [allergens, setAllergens] = useState('');
  const [cuisines, setCuisines] = useState<string[]>([]); const [mealType, setMealType] = useState('dinner'); const [maxTime, setMaxTime] = useState(60); const [servings, setServings] = useState(2); const [skill, setSkill] = useState('easy');
  const [recipes, setRecipes] = useState<Recipe[]>([]); const [saved, setSaved] = useState<Recipe[]>([]); const [pantry, setPantry] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(false); const [msg, setMsg] = useState('');
  useEffect(() => { idb.getAll<PantryItem>('pantry').then(setPantry).catch(() => {}); idb.getAll<Recipe>('recipes').then(setSaved).catch(() => {}); }, []);
  async function generate() {
    const ingredients = parseIngredients(text || pantry.map(p => p.name).join(','));
    if (!ingredients.length) { setMsg('Add at least one ingredient, or add items to your Pantry first.'); return; }
    setLoading(true); setMsg('');
    if (!navigator.onLine) { setRecipes(offlineGenerate(ingredients, 3, cuisines)); setMsg('Offline: showing built-in recipes' + (cuisines.length ? ` for ${cuisines.join(', ')}` : '') + '.'); setLoading(false); return; }
    try {
      const res = await fetch('/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ingredients, diet, allergens: parseIngredients(allergens), cuisines, mealType, maxTime, servings, skill }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || 'failed');
      setRecipes(data.recipes); setMsg(`Generated via ${data.provider}. ${data.note || ''}`);
    } catch (e) { setRecipes(offlineGenerate(ingredients, 3, cuisines)); setMsg('AI unavailable — showing offline recipes instead.'); }
    setLoading(false);
  }
  async function save(r: Recipe) { const s = { ...r, source: 'saved' as const }; await idb.put('recipes', s); setSaved(p => [...p.filter(x => x.id !== s.id), s]); setMsg('Saved for offline use ✓'); }
  async function addShop(r: Recipe) { const items = buildShoppingList([r], pantry); for (const i of items) await idb.put('shop', i); setMsg(items.length ? `Added ${items.length} missing item(s) to Shop.` : 'You already have everything (excluding staples).'); }
  async function cooked(r: Recipe) { const { deductPantry } = await import('@/lib/planning'); const next = deductPantry(pantry, r); for (const p of next) await idb.put('pantry', p); setPantry(next); setMsg('Pantry deducted (never below zero) ✓'); }
  return <div className="space-y-5">
    <section className="rounded-3xl bg-forest text-white p-6 sm:p-10">
      <h1 className="font-serif text-3xl sm:text-5xl font-bold">What&apos;s in your fridge tonight?</h1>
      <p className="mt-2 opacity-90">Tell Fridge Chef what you have. Get 3 recipes that respect your diet — online with AI, offline with the built-in library.</p>
      <a href="#generator" className="btn !bg-warm mt-4">Start cooking ↓</a>
    </section>
    <section id="generator" className="card space-y-3">
      <label className="font-bold block">Ingredients <span className="font-normal text-sm opacity-70">(one per line, or comma-separated — paste a list works too)</span>
        <textarea className="input mt-1 min-h-[110px]" value={text} onChange={e => setText(e.target.value)} placeholder={'chicken\nrice\nspinach'} /></label>
      <p className="text-sm">In your pantry: <strong>{pantry.length ? pantry.map(p => p.name).join(', ') : 'nothing yet — add items in Pantry'}</strong></p>
      <div className="grid sm:grid-cols-3 gap-3">
        <label className="text-sm font-semibold">Diet<select className="input mt-1" value={diet} onChange={e => setDiet(e.target.value as Diet)}><option value="omnivore">Omnivore</option><option value="vegetarian">Vegetarian</option><option value="vegetarian-no-egg">Vegetarian (no eggs)</option><option value="vegan">Vegan</option></select></label>
        <label className="text-sm font-semibold">Meal<select className="input mt-1" value={mealType} onChange={e => setMealType(e.target.value)}><option>breakfast</option><option>lunch</option><option>dinner</option><option>snack</option></select></label>
        <label className="text-sm font-semibold">Max minutes<input type="number" className="input mt-1" value={maxTime} onChange={e => setMaxTime(Number(e.target.value))} /></label>
        <label className="text-sm font-semibold">Servings<input type="number" min={1} max={12} className="input mt-1" value={servings} onChange={e => setServings(Number(e.target.value))} /></label>
        <label className="text-sm font-semibold">Skill<select className="input mt-1" value={skill} onChange={e => setSkill(e.target.value)}><option>easy</option><option>medium</option><option>hard</option></select></label>
      </div>
      <CuisinePicker selected={cuisines} onChange={setCuisines} />
      <label className="text-sm font-semibold block">Allergen exclusions <span className="font-normal opacity-70">(warning: AI cannot guarantee allergen safety — always check labels)</span><input className="input mt-1" value={allergens} onChange={e => setAllergens(e.target.value)} placeholder="e.g. peanut, shellfish" /></label>
      <button className="btn w-full sm:w-auto" onClick={generate} disabled={loading}>{loading ? 'Cooking up recipes…' : '✨ Generate 3 recipes'}</button>
      {msg && <p role="status" className="text-sm bg-sageLight dark:bg-[#24382D] rounded-xl p-3">{msg}</p>}
      {loading && <div className="space-y-3" aria-label="Loading"><div className="skeleton h-32" /><div className="skeleton h-32" /></div>}
    </section>
    <DishGuide pantry={pantry} onSave={save} onShop={addShop} />
    <section className="space-y-4">{recipes.map(r => <RecipeCard key={r.id} recipe={r} pantry={pantry} onSave={() => save(r)} onShop={() => addShop(r)} onCooked={() => cooked(r)} />)}</section>
    {saved.length > 0 && <section><h2 className="font-serif text-2xl font-bold mb-3">Saved recipes (available offline)</h2><div className="space-y-4">{saved.map(r => <RecipeCard key={r.id} recipe={r} pantry={pantry} onShop={() => addShop(r)} />)}</div></section>}
    <section><h2 className="font-serif text-2xl font-bold mb-3">Built-in offline collection</h2><div className="space-y-4">{OFFLINE_RECIPES.slice(0, 3).map(r => <RecipeCard key={r.id} recipe={r} pantry={pantry} onSave={() => save(r)} onShop={() => addShop(r)} />)}</div></section>
  </div>;
}
