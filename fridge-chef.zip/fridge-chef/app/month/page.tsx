'use client';
import { useState } from 'react'; import { planMonth, buildShoppingList, totalCost, type MonthPlanResult } from '@/lib/planning'; import { idb, uid } from '@/lib/db';
import { OFFLINE_RECIPES, recipesForCuisines } from '@/lib/offline-recipes'; import CuisinePicker from '@/components/CuisinePicker';
export default function MonthPage() {
  const now = new Date(); const [ym, setYm] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`);
  const [budget, setBudget] = useState(100); const [restaurantNights, setRestaurantNights] = useState(4); const [repeats, setRepeats] = useState(true); const [plan, setPlan] = useState<MonthPlanResult | null>(null); const [msg, setMsg] = useState(''); const [cuisines, setCuisines] = useState<string[]>([]);
  function generate() { const [y, m] = ym.split('-').map(Number); const p = planMonth(y, m - 1, { budget, restaurantNights, allowRepeats: repeats, cuisines }); setPlan(p); setMsg(p.fitsBudget ? `Plan fits: $${p.totalCost.toFixed(2)} total.` : `Cannot meet $${budget}: lowest estimated total is $${p.totalCost.toFixed(2)} — $${p.overBudget.toFixed(2)} over budget. Increase budget to approve.`); }
  async function toShop() { if (!plan) return; const recipes = plan.days.filter(d => d.recipe).map(d => d.recipe!); const items = buildShoppingList(recipes, []); for (const i of items) await idb.put('shop', i); setMsg(`Consolidated shopping list created: ${items.length} items, est. $${totalCost(items).toFixed(2)} (estimates, flagged in Shop).`); }
  function swap(idx: number) { if (!plan) return; const copy = { ...plan, days: [...plan.days] }; const cur = copy.days[idx]; if (cur.recipe) { const pool = recipesForCuisines(cuisines); copy.days[idx] = { ...cur, recipe: pool[(pool.indexOf(cur.recipe) + 1 + pool.length) % pool.length] || OFFLINE_RECIPES[0] }; setPlan(copy); } }
  return <div className="space-y-5"><h1 className="font-serif text-3xl font-bold">Month — dinner planner</h1>
    <section className="card grid sm:grid-cols-4 gap-3">
      <label className="text-sm font-semibold">Month<input type="month" className="input mt-1" value={ym} onChange={e => setYm(e.target.value)} /></label>
      <label className="text-sm font-semibold">Budget $ (editable)<input type="number" min={0} className="input mt-1" value={budget} onChange={e => setBudget(Number(e.target.value))} /></label>
      <label className="text-sm font-semibold">Restaurant nights<input type="number" min={0} max={31} className="input mt-1" value={restaurantNights} onChange={e => setRestaurantNights(Number(e.target.value))} /></label>
      <label className="text-sm font-semibold flex items-end gap-2"><input type="checkbox" checked={repeats} onChange={e => setRepeats(e.target.checked)} className="w-5 h-5" /> Allow repeats</label>
      <button className="btn" onClick={generate}>Generate month plan</button>
    </section>
    <section className="card"><CuisinePicker selected={cuisines} onChange={setCuisines} label="Menu cuisines for this month (specific regions & styles)" /></section>
    {msg && <p role="status" className="card text-sm">{msg}</p>}
    {plan && <><section className="card grid grid-cols-3 gap-3 text-center"><div><p className="text-2xl font-bold">${plan.groceryCost.toFixed(2)}</p><p className="text-xs">Est. groceries</p></div><div><p className="text-2xl font-bold">${plan.restaurantCost.toFixed(2)}</p><p className="text-xs">Restaurant nights</p></div><div><p className="text-2xl font-bold">${plan.totalCost.toFixed(2)}</p><p className="text-xs">Total spend</p></div></section>
    <button className="btn-secondary" onClick={toShop}>🛒 Generate consolidated shopping list</button>
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">{plan.days.map((d, i) => <div key={d.date} className="card !p-3 text-sm"><p className="font-bold">{d.date.slice(8)}</p>{d.restaurant ? <p>🍽️ Restaurant</p> : <><p>{d.recipe?.title}</p><p className="text-xs italic">{d.recipe?.cuisine}</p><p className="text-xs">{d.recipe?.nutrition.calories} kcal · ${d.recipe?.estimatedCost.toFixed(2)}</p><button className="btn-secondary !min-h-[36px] !py-1 mt-1 text-xs" onClick={() => swap(i)}>Swap</button></>}</div>)}</div></>}
  </div>;
}
