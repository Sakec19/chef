import './globals.css'; import Nav from '@/components/Nav'; import type { Metadata, Viewport } from 'next';
export const metadata: Metadata = { title: 'Fridge Chef — Cook what you have', description: 'AI-powered recipes from your fridge, pantry manager, meal planner and shopping list. Works offline.', manifest: '/manifest.json', appleWebApp: { capable: true, title: 'Fridge Chef', statusBarStyle: 'default' } };
export const viewport: Viewport = { themeColor: '#1E3D2F', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body className="font-sans pb-20 md:pb-6"><Nav /><main className="max-w-5xl mx-auto px-4 py-4">{children}</main>
  <footer className="max-w-5xl mx-auto px-4 pb-24 md:pb-8 text-xs opacity-70">Nutrition values are estimates, not medical advice. AI recipes cannot guarantee allergen safety — always check ingredient labels.</footer></body></html>;
}
