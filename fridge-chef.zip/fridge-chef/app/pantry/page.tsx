'use client';
import { useEffect, useState } from 'react'; import { idb, uid } from '@/lib/db'; import { daysUntilExpiry } from '@/lib/planning'; import { offlineGenerate } from '@/lib/offline-recipes'; import type { Location, PantryItem } from '@/lib/types'; import RecipeCard from '@/components/RecipeCard';
export default function PantryPage() {
  const [items, setItems] = useState<PantryItem[]>([]); const [history, setHistory] = useState<{id:string;name:string;delta:number;unit:string;reason:string;at:number}[]>([]);
  const [form, setForm] = useState({ name: '', quantity: 1, unit: 'g', category: 'Other', location: 'fridge' as Location, expiryDate: '', purchaseDate: '' });
  useEffect(() => { idb.getAll<PantryItem>('pantry').then(setItems).catch(() => {}); idb.getAll('history').then(h => setHistory(h as typeof history)).catch(() => {}); }, []);
  async function add(e: React.FormEvent) { e.preventDefault(); if (!form.name.trim()) return;
    // Aggregate identical compatible items
    const existing = items.find(i => i.name.toLowerCase() === form.name.toLowerCase() && i.unit === form.unit && i.location === form.location);
    const item: PantryItem = existing ? { ...existing, quantity: existing.quantity + Number(form.quantity) } : { id: uid(), ...form, quantity: Number(form.quantity), createdAt: Date.now() };
    await idb.put('pantry', item); const h = { id: uid(), pantryId: item.id, name: item.name, delta: Number(form.quantity), unit: form.unit, reason: 'added', at: Date.now() }; await idb.put('history', h);
    setItems(p => [...p.filter(i => i.id !== item.id), item]); setHistory(p => [h, ...p]); setForm({ ...form, name: '', quantity: 1 });
  }
  async function adjust(item: PantryItem, delta: number) { const next = { ...item, quantity: Math.max(0, item.quantity + delta) }; await idb.put('pantry', next); setItems(p => p.map(i => i.id === item.id ? next : i)); }
  async function remove(item: PantryItem) { await idb.del('pantry', item.id); setItems(p => p.filter(i => i.id !== item.id)); }
  const expiring = items.filter(i => { const d = daysUntilExpiry(i); return d !== null && d <= 3; });
  const suggestions = expiring.length ? offlineGenerate(expiring.map(i => i.name), 2) : [];
  return <div className="space-y-5"><h1 className="font-serif text-3xl font-bold">Pantry</h1>
    {expiring.length > 0 && <div role="alert" className="card !bg-orange-50 dark:!bg-[#3A2A1A]"><strong>⚠️ Expiring soon:</strong> {expiring.map(i => `${i.name} (${daysUntilExpiry(i)}d)`).join(', ')}. Recipes below use them first.</div>}
    {suggestions.map(r => <RecipeCard key={r.id} recipe={r} pantry={items} />)}
    <form onSubmit={add} className="card grid sm:grid-cols-3 gap-3">
      <label className="text-sm font-semibold">Name<input required className="input mt-1" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
      <label className="text-sm font-semibold">Quantity<input type="number" min={0} step="any" className="input mt-1" value={form.quantity} onChange={e => setForm({ ...form, quantity: Number(e.target.value) })} /></label>
      <label className="text-sm font-semibold">Unit<select className="input mt-1" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })}><option>g</option><option>kg</option><option>ml</option><option>l</option><option>cup</option><option>tbsp</option><option>tsp</option><option>piece</option></select></label>
      <label className="text-sm font-semibold">Storage<select className="input mt-1" value={form.location} onChange={e => setForm({ ...form, location: e.target.value as Location })}><option>fridge</option><option>freezer</option><option>shelf</option></select></label>
      <label className="text-sm font-semibold">Category<input className="input mt-1" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /></label>
      <label className="text-sm font-semibold">Expiry (optional)<input type="date" className="input mt-1" value={form.expiryDate} onChange={e => setForm({ ...form, expiryDate: e.target.value })} /></label>
      <label className="text-sm font-semibold">Purchased (optional)<input type="date" className="input mt-1" value={form.purchaseDate} onChange={e => setForm({ ...form, purchaseDate: e.target.value })} /></label>
      <button className="btn self-end">Add item</button>
    </form>
    {(['fridge','freezer','shelf'] as Location[]).map(loc => <section key={loc}><h2 className="font-bold capitalize text-lg mt-2">{loc}</h2>
      {items.filter(i => i.location === loc).length === 0 ? <p className="text-sm opacity-70">Nothing here yet.</p> : <ul className="space-y-2">{items.filter(i => i.location === loc).map(i => <li key={i.id} className="card flex flex-wrap gap-2 items-center justify-between"><span><strong>{i.name}</strong> — {i.quantity} {i.unit} · {i.category}{i.expiryDate ? ` · expires ${i.expiryDate}` : ''}</span><span className="flex gap-1"><button className="btn-secondary" onClick={() => adjust(i, -1)} aria-label="Decrease">−</button><button className="btn-secondary" onClick={() => adjust(i, 1)} aria-label="Increase">+</button><button className="btn-secondary" onClick={() => remove(i)}>Delete</button></span></li>)}</ul>}</section>)}
    {history.length > 0 && <section className="card"><h2 className="font-bold">Adjustment history</h2><ul className="text-sm list-disc pl-5">{history.slice(0, 10).map(h => <li key={h.id}>{new Date(h.at).toLocaleString()}: {h.delta > 0 ? '+' : ''}{h.delta} {h.unit} {h.name} ({h.reason})</li>)}</ul></section>}
  </div>;
}
