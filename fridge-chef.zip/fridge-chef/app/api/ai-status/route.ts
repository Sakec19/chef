import { NextResponse } from 'next/server';
import { providerStatus } from '@/lib/server-ai';

export const runtime = 'nodejs';
// Safe by design: returns only whether each provider has a key configured, the model name, and where to get a key.
// NEVER returns key values, prefixes, or lengths.
export async function GET() {
  return NextResponse.json({ ...providerStatus(), note: 'Configured means an env var is present on the server — it does not guarantee the key is valid or billing is active. The first real generation call is the true test.' });
}
