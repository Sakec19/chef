import { NextRequest, NextResponse } from 'next/server';
import { callAI, extractJson, rateLimited } from '@/lib/server-ai';
import { findDish, scaleRecipeToServings, listGuideDishes } from '@/lib/dish-guide';
import { validateRecipes } from '@/lib/dietary';
import { calculateNutrition } from '@/lib/nutrition';
import { isSpecificCuisine } from '@/lib/cuisines';
import type { DishGuideRequest, Recipe } from '@/lib/types';

export const runtime = 'nodejs';

function promptFor(body: DishGuideRequest) {
  return `Return ONLY valid JSON for ONE dish: {"recipes":[{ "title":"","description":"","cuisine":"","mealType":"dinner","timeMinutes":30,"servings":${body.servings},"difficulty":"medium","estimatedCost":5,"benefits":[],"tags":[],"ingredients":[{"name":"","quantity":100,"unit":"g","optional":false,"staple":false}],"steps":[""] }]}. Dish requested: "${body.dish}". Give a complete, accurate, traditional recipe with precise quantities and DETAILED step-by-step instructions (each step one clear action, include times and temperatures where relevant, in cooking order). The "cuisine" must be the SPECIFIC regional cuisine of this dish (e.g. "Punjabi", "Gujarati", "Hyderabadi", "Neapolitan", "Sichuan") — NEVER a generic label like "Indian" or "Asian". Diet (HARD RULE): ${body.diet || 'omnivore'} — if the traditional dish violates this diet, adapt it and say so in the description. Allergens to exclude: ${(body.allergens || []).join(', ') || 'none'}. Mark salt/oil/common spices as staple:true. Do not invent nutrition fields.`;
}
function parseGuide(text: string, source: 'gemini' | 'openrouter' | 'cerebras' | 'groq' | 'muse', servings: number): Recipe {
  const data = extractJson(text) as { recipes?: Record<string, unknown>[] };
  if (!Array.isArray(data.recipes) || !data.recipes.length) throw new Error('Bad schema');
  const r = data.recipes[0];
  const ingredients = (r.ingredients as Recipe['ingredients']) || [];
  const sv = Number(r.servings) || servings;
  const recipe: Recipe = { id: `${source}-guide-${Date.now()}`, title: String(r.title || 'Dish'), description: String(r.description || ''), cuisine: String(r.cuisine || ''), mealType: String(r.mealType || 'dinner'), timeMinutes: Number(r.timeMinutes) || 30, servings: sv, difficulty: (['easy', 'medium', 'hard'].includes(String(r.difficulty)) ? r.difficulty : 'medium') as Recipe['difficulty'], ingredients, steps: (r.steps as string[]) || [], benefits: (r.benefits as string[]) || [], tags: (r.tags as string[]) || [], estimatedCost: Number(r.estimatedCost) || 5, source, nutrition: calculateNutrition(ingredients, sv) };
  if (!recipe.steps.length || !recipe.ingredients.length) throw new Error('Incomplete recipe');
  if (recipe.cuisine && !isSpecificCuisine(recipe.cuisine)) recipe.cuisine = recipe.cuisine + ' (regional style unspecified by provider)';
  return scaleRecipeToServings(recipe, servings);
}
export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'local';
    if (rateLimited(ip)) return NextResponse.json({ error: 'Rate limit: 30 AI requests/hour. Offline dish guides still work.' }, { status: 429 });
    const raw = await req.text(); if (raw.length > 4000) return NextResponse.json({ error: 'Request too large' }, { status: 413 });
    const body = JSON.parse(raw) as DishGuideRequest;
    const dish = String(body.dish || '').slice(0, 80).trim();
    if (!dish) return NextResponse.json({ error: 'Enter a dish name' }, { status: 400 });
    const servings = Math.min(12, Math.max(1, Number(body.servings) || 2));
    // Offline library first is NOT forced — AI gives richer guides — but it is the guaranteed fallback.
    try {
      const { text, provider } = await callAI(promptFor({ ...body, dish, servings }));
      const recipe = parseGuide(text, provider, servings);
      const valid = validateRecipes([recipe], body.diet || 'omnivore', body.allergens || []);
      if (!valid.length) throw new Error('AI recipe violated diet/allergen rules');
      return NextResponse.json({ recipe: valid[0], provider, note: 'Nutrition is estimated from ingredient data — not medical advice. AI recipes cannot guarantee allergen safety.' });
    } catch {
      const offline = findDish(dish);
      if (offline) {
        const scaled = scaleRecipeToServings(offline, servings);
        const valid = validateRecipes([scaled], body.diet || 'omnivore', body.allergens || []);
        if (valid.length) return NextResponse.json({ recipe: valid[0], provider: 'offline', note: 'From the built-in offline dish library. Nutrition is estimated — not medical advice.' });
        return NextResponse.json({ error: `"${offline.title}" is in the offline library but does not fit the selected diet/allergen rules, and AI is unavailable to adapt it.` }, { status: 422 });
      }
      return NextResponse.json({ error: `AI is unavailable and "${dish}" is not in the offline dish library.`, availableOffline: listGuideDishes() }, { status: 503 });
    }
  } catch { return NextResponse.json({ error: 'Could not load that dish guide.' }, { status: 500 }); }
}
