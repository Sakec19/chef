import { NextRequest, NextResponse } from 'next/server';
import { validateRecipes } from '@/lib/dietary';
import { offlineGenerate } from '@/lib/offline-recipes';
import { calculateNutrition } from '@/lib/nutrition';
import type { GenerateRequest, Recipe } from '@/lib/types';
import { sanitizeCuisines, recipeMatchesCuisines } from '@/lib/cuisines';
import { callAI } from '@/lib/server-ai';

export const runtime = 'nodejs';
// Simple in-memory rate limit (per IP, resets hourly). For multi-instance production, replace with Upstash/Redis — documented in README.
const hits = new Map<string, { count: number; reset: number }>();
function rateLimited(ip: string) {
  const now = Date.now(); const cur = hits.get(ip);
  if (!cur || now > cur.reset) { hits.set(ip, { count: 1, reset: now + 3600_000 }); return false; }
  cur.count++; return cur.count > 30;
}
function promptFor(body: GenerateRequest) {
  const cuisines = sanitizeCuisines(body.cuisines);
  const cuisineRule = cuisines.length
    ? `Cuisines (HARD RULE): every recipe must belong to one of these SPECIFIC cuisines: ${cuisines.join(', ')}. Set each recipe's "cuisine" field to exactly one of those names. NEVER use generic labels like "Indian", "Asian", "Chinese" or "Italian" — regional specificity matters (e.g. Punjabi is not Gujarati, Cantonese is not Sichuan).`
    : `Cuisine: use a SPECIFIC regional cuisine name for each recipe (e.g. Punjabi, Gujarati, Sichuan, Neapolitan, Oaxacan). NEVER label a recipe with a generic term like "Indian", "Asian" or "Mediterranean".`;
  return `Return ONLY valid JSON: {"recipes":[{ "title":"","description":"","cuisine":"","mealType":"","timeMinutes":20,"servings":${body.servings},"difficulty":"easy","estimatedCost":5,"benefits":[],"tags":[],"ingredients":[{"name":"","quantity":100,"unit":"g","optional":false,"staple":false}],"steps":[""] }]}. Create exactly 3 varied recipes using mainly: ${body.ingredients.join(', ')}. Diet (HARD RULE, never violate): ${body.diet}. Allergens to exclude: ${body.allergens.join(', ') || 'none'}. ${cuisineRule} Meal: ${body.mealType || 'any'}, maxTime: ${body.maxTime || 60} min, skill: ${body.skill || 'any'}. Mark salt/oil/spices as staple:true. Do not invent nutrition fields.`;
}
function parseRecipes(text: string, source: 'gemini'|'openrouter'|'cerebras'|'groq'|'muse'): Recipe[] {
  const match = text.match(/\{[\s\S]*\}/); if (!match) throw new Error('No JSON');
  const data = JSON.parse(match[0]);
  if (!Array.isArray(data.recipes)) throw new Error('Bad schema');
  return data.recipes.slice(0, 3).map((r: Record<string, unknown>, i: number) => {
    const ingredients = (r.ingredients as Recipe['ingredients']) || [];
    const servings = Number(r.servings) || 2;
    return { id: `${source}-${Date.now()}-${i}`, title: String(r.title || 'Recipe'), description: String(r.description || ''), cuisine: String(r.cuisine || ''), mealType: String(r.mealType || 'dinner'), timeMinutes: Number(r.timeMinutes) || 30, servings, difficulty: (['easy','medium','hard'].includes(String(r.difficulty)) ? r.difficulty : 'easy') as Recipe['difficulty'], ingredients, steps: (r.steps as string[]) || [], benefits: (r.benefits as string[]) || [], tags: (r.tags as string[]) || [], estimatedCost: Number(r.estimatedCost) || 5, source, nutrition: calculateNutrition(ingredients, servings) };
  });
}
export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'local';
    if (rateLimited(ip)) return NextResponse.json({ error: 'Rate limit: 30 AI requests/hour. Offline recipes still work.' }, { status: 429 });
    const raw = await req.text(); if (raw.length > 8000) return NextResponse.json({ error: 'Request too large' }, { status: 413 });
    const body = JSON.parse(raw) as GenerateRequest;
    if (!Array.isArray(body.ingredients) || body.ingredients.length === 0 || body.ingredients.length > 50) return NextResponse.json({ error: 'Add 1-50 ingredients' }, { status: 400 });
    body.ingredients = body.ingredients.map(s => String(s).slice(0, 60)); body.allergens = (body.allergens || []).slice(0, 20); body.servings = Math.min(12, Math.max(1, Number(body.servings) || 2));
    let recipes: Recipe[] = []; let provider = 'offline';
    try { const ai = await callAI(promptFor(body)); recipes = parseRecipes(ai.text, ai.provider); provider = ai.provider; } catch { recipes = offlineGenerate(body.ingredients, 3, sanitizeCuisines(body.cuisines)); }
    const valid = validateRecipes(recipes, body.diet, body.allergens);
    const cuisines = sanitizeCuisines(body.cuisines);
    let final = valid;
    if (cuisines.length && final.length) {
      // Enforce the cuisine selection: keep matches, top up from the offline library for that cuisine.
      const matching = final.filter(r => recipeMatchesCuisines(r.cuisine, cuisines));
      if (matching.length) {
        final = matching;
        if (final.length < 3) {
          const extra = offlineGenerate(body.ingredients, 3, cuisines).filter(o => !final.some(f => f.title === o.title));
          final = [...final, ...extra].slice(0, 3);
        }
      }
      // If the AI ignored the cuisine rule entirely, final stays as-is rather than returning nothing —
      // but its recipes keep their own (specific) cuisine labels, never a generic relabel.
    }
    if (!final.length) final = offlineGenerate(body.ingredients, 3, cuisines);
    return NextResponse.json({ recipes: final, provider: final[0]?.source || provider, note: 'Nutrition is estimated from ingredient data where available — not medical advice. AI recipes cannot guarantee allergen safety; always check labels.' });
  } catch { return NextResponse.json({ error: 'Could not generate recipes. Try offline recipes.' }, { status: 500 }); }
}
