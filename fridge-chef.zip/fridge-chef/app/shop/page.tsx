'use client';
import { useEffect, useState } from 'react'; import { idb, uid } from '@/lib/db'; import { totalCost } from '@/lib/planning'; import type { ShopItem } from '@/lib/types';
export default function ShopPage() {
  const [items, setItems] = useState<ShopItem[]>([]); const [custom, setCustom] = useState('');
  useEffect(() => { idb.getAll<ShopItem>('shop').then(setItems).catch(() => {}); }, []);
  async function persist(next: ShopItem[]) { setItems(next); for (const i of next) await idb.put('shop', i); }
  async function toggle(i: ShopItem) { await persist(items.map(x => x.id === i.id ? { ...x, checked: !x.checked } : x)); }
  async function addCustom() { if (!custom.trim()) return; const item: ShopItem = { id: uid(), name: custom.trim(), quantity: 1, unit: 'piece', category: 'Other', unitPrice: 0, priceCertain: false, checked: false }; await idb.put('shop', item); setItems(p => [...p, item]); setCustom(''); }
  async function remove(i: ShopItem) { await idb.del('shop', i.id); setItems(p => p.filter(x => x.id !== i.id)); }
  function shareText() { const txt = items.map(i => `${i.checked ? '✓' : '•'} ${i.quantity} ${i.unit} ${i.name} — est. $${(i.quantity * i.unitPrice).toFixed(2)}${i.priceCertain ? '' : ' (estimate)'}`).join('\n'); navigator.share?.({ title: 'Fridge Chef shopping list', text: txt }).catch(() => navigator.clipboard?.writeText(txt)); }
  function exportJson() { const blob = new Blob([JSON.stringify(items, null, 2)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'fridge-chef-shopping.json'; a.click(); }
  const groups = Array.from(new Set(items.map(i => i.category)));
  return <div className="space-y-5"><h1 className="font-serif text-3xl font-bold">Shop</h1>
    <section className="card flex gap-2"><input className="input" value={custom} onChange={e => setCustom(e.target.value)} placeholder="Add a custom item…" aria-label="Custom item" /><button className="btn" onClick={addCustom}>Add</button></section>
    <p className="card"><strong>Estimated total: ${totalCost(items.filter(i => !i.checked)).toFixed(2)}</strong> remaining · Prices marked <em>estimate</em> are not verified store prices.</p>
    {items.length === 0 && <div className="card text-center py-10"><p className="text-4xl">🛒</p><p className="font-semibold mt-2">Your list is empty</p><p className="text-sm opacity-70">Generate recipes in Cook, Month or My Days and add missing ingredients.</p></div>}
    {groups.map(g => <section key={g}><h2 className="font-bold text-lg">{g}</h2><ul className="space-y-2">{items.filter(i => i.category === g).map(i => <li key={i.id} className="card flex items-center gap-3"><input type="checkbox" checked={i.checked} onChange={() => toggle(i)} className="w-6 h-6" aria-label={`Check ${i.name}`} /><span className={i.checked ? 'line-through opacity-60 flex-1' : 'flex-1'}><strong>{i.name}</strong> — {i.quantity} {i.unit} · ${i.unitPrice.toFixed(2)}/unit · <strong>${(i.quantity * i.unitPrice).toFixed(2)}</strong> {i.priceCertain ? '' : <em>(estimate)</em>}</span><button className="btn-secondary" onClick={() => remove(i)}>Delete</button></li>)}</ul></section>)}
    <div className="flex gap-2 flex-wrap"><button className="btn-secondary" onClick={shareText}>Share as text</button><button className="btn-secondary" onClick={exportJson}>Export JSON</button></div>
  </div>;
}
